function valid()
{
 var x=document.forms["myform"]["em"].value;
  var z=x.indexOf('@');
  var pass=document.forms["myform"]["pass"].value;
  if(x=="" ||x==null)
  {
	alert("email must fill out");
  return false;
  }
	else if(z<1){
		alert("email must contain @ character");
	return false;
	}
	 if(pass=="" ||pass==null){
		alert("password must fill out");
	return false;
	}
	else if(pass.length<6){
		alert("password must more than 6 and less than 12");
	return false;
	}
	else if(pass.length >12){
		alert("password must less than 12");
	return false;
	}
	
	 	 
}



function insert()
{
	var user=document.forms["myform"]["user"].value;
	var email=document.forms["myform"]["email"].value;
	var add=email.indexOf('@');
	var gender=document.forms["myform"]["gender"].value;
	var phone=document.forms["myform"]["phone"].value;
	var password=document.forms["myform"]["password"].value;

	 
	
	if(user=="" ||user==null)
	{
	  alert("username must fill out");
	return false;
	}
	else if(user.length<3||user.length>25){
		alert("character of username must more than 3 and less than 20");
	return false;
	}

	if(email=="" ||email==null)
	{
	  alert("email must fill out");
	return false;
	}
	  else if(add<1){
		  alert("email must contain @ character");
	  return false;
	  }
	   if(password=="" ||password==null){
		  alert("password must fill out");
	  return false;
	  }
	  else if(password.length<6||password.length>11){
		  alert("password must more than 6 and less than 12");
	  return false;
	  }
	  else if(password.length >12){
		  alert("password must less than 12");
	  return false;
	  }
	  if(gender=="" ||gender==null)
	{
	  alert("gender must fill out male or female");
	return false;
	}
	else if(gender.length>6||gender.length<4)
	{
	  alert("gender must fill out male or female");
	return false;
	}
	 
	 
	if(phone=="" ||phone==null)
	{
	  alert("phone must fill out");
	return false;
	}
	else if(phone.length<11||phone.length>11)
	{
	  alert("phone must fill out 11 number");
	return false;
	}
	 

}
 /////////////////////////////////
 function inserts()
 {

	var user=document.forms["myform"]["user"].value;
	var email_s=document.forms["myform"]["email_s"].value;
	var add=email_s.indexOf('@');
	var age=document.forms["myform"]["age"].value;
	var route=document.forms["myform"]["route"].value;
	var img=document.forms["myform"]["img"].value;
	var city=document.forms["myform"]["city"].value;
	var country=document.forms["myform"]["country"].value;
	var street=document.forms["myform"]["street"].value;
	var gender_s=document.forms["myform"]["gender_s"].value;
	 var password=document.forms["myform"]["password"].value;
	 var email=document.forms["myform"]["email"].value;
	 var addp=email.indexOf('@');
	 var classes=document.forms["myform"]["class"].value;



	 
	
	if(user=="" ||user==null)
	{
	  alert("username must fill out");
	return false;
	}
	else if(user.length<3||user.length>25){
		alert("character of username must more than 3 and less than 20");
	return false;
	}
	
	if(email_s=="" ||email_s==null)
	{
	  alert("email_student must fill out");
	return false;
	}
	  else if(add<1){
		  alert("email must contain @ character");
	  return false;
	  }
	   if(password=="" ||password==null){
		  alert("password must fill out");
	  return false;
	  }
	  else if(password.length<6||password.length>11){
		  alert("password must more than 6 and less than 12");
	  return false;
	  }
	  else if(password.length >12){
		  alert("password must less than 12");
	  return false;
	  }
	  if(img=="" ||img==null)
	{
	  alert("image must be selected ");
	return false;
	}
	if(age=="" ||age==null)
	{
	  alert("age must fill out ");
	return false;
	}
	if(classes=="" ||classes==null)
	{
	  alert("class must fill out ");
	return false;
	}

	  if(gender_s=="" ||gender_s==null)
	{
	  alert("gender must fill out male or female");
	return false;
	}
	else if(gender_s.length>6||gender_s.length<4)
	{
	  alert("gender must fill out male or female");
	return false;
	}
	
	if(country=="" ||country==null)
	{
	  alert("country must fill out ");
	return false;
	}
	if(city=="" ||city==null)
	{
	  alert("city must fill out ");
	return false;
	}
	if(street=="" ||street==null)
	{
	  alert("street must fill out ");
	return false;
	}
	if(route=="" ||route==null)
	{
	  alert("route must fill out ");
	return false;
	}
	
	if(email=="" ||email==null)
	{
	  alert("email parent must fill out");
	return false;
	}
	else if(addp<1){
		alert("email must contain @ character");
	return false;
	}
	 
 }
 ///////////////////////////////////////
 function insertteacher()
 {
	var user=document.forms["myform"]["user"].value;
	var email=document.forms["myform"]["email"].value;
	var add=email.indexOf('@');
	var age=document.forms["myform"]["age"].value;
 	var img=document.forms["myform"]["img"].value;
	var city=document.forms["myform"]["city"].value;
	var country=document.forms["myform"]["country"].value;
	var street=document.forms["myform"]["street"].value;
	var gender=document.forms["myform"]["gender"].value;
	 var password=document.forms["myform"]["password"].value;
	 var phone=document.forms["myform"]["phone"].value;
	 var career=document.forms["myform"]["career"].value;


	 
	
	if(user=="" ||user==null)
	{
	  alert("username must fill out");
	return false;
	}
	else if(user.length<3||user.length>25){
		alert("character of username must more than 3 and less than 20");
	return false;
	}
	
	if(email=="" ||email==null)
	{
	  alert("email must fill out");
	return false;
	}
	  else if(add<1){
		  alert("email must contain @ character");
	  return false;
	  }
	  if(age=="" ||age==null)
	{
	  alert("age must fill out ");
	return false;
	}
	if(gender=="" ||gender==null)
	{
	  alert("gender must fill out male or female");
	return false;
	}
	else if(gender.length>6||gender.length<4)
	{
	  alert("gender must fill out male or female");
	return false;
	}

	if(phone=="" ||phone==null)
	{
	  alert("phone must fill out");
	return false;
	}
	else if(phone.length<11||phone.length>11)
	{
	  alert("phone must fill out 11 number");
	return false;
	}
	 

	if(img=="" ||img==null)
	{
	  alert("image must be selected ");
	return false;
	}
	if(career=="" ||career==null)
	{
	  alert("career must fill out ");
	return false;
	}
	if(country=="" ||country==null)
	{
	  alert("country must fill out ");
	return false;
	}
	if(city=="" ||city==null)
	{
	  alert("city must fill out ");
	return false;
	}
	if(street=="" ||street==null)
	{
	  alert("street must fill out ");
	return false;
	}
	if(password=="" ||password==null){
		alert("password must fill out");
	return false;
	}
	else if(password.length<6||password.length>11){
		alert("password must more than 6 and less than 12");
	return false;
	}
	else if(password.length >12){
		alert("password must less than 12");
	return false;
	}
		  
 }
 function insertdriver()
 {
	var user=document.forms["myform"]["username"].value;
	var emaildr=document.forms["myform"]["emaildr"].value;
	var adddr=emaildr.indexOf('@');
	var age=document.forms["myform"]["age"].value;
 	var img=document.forms["myform"]["img"].value;
	var city=document.forms["myform"]["city"].value;
	var country=document.forms["myform"]["country"].value;
	var street=document.forms["myform"]["street"].value;
 	 var password=document.forms["myform"]["passworddr"].value;
 	 var license=document.forms["myform"]["license"].value;


	 if(user=="" ||user==null)
	{
	  alert("username must fill out");
	return false;
	}
	else if(user.length<3||user.length>25){
		alert("character of username must more than 3 and less than 20");
	return false;
	}
	
	if(emaildr=="" ||emaildr==null)
	{
	  alert("email must fill out");
	return false;
	}
	  else if(adddr<1){
		  alert("email must contain @ character");
	  return false;
	  }
	  if(password=="" ||password==null){
		alert("password must fill out");
	return false;
	}
	else if(password.length<6||password.length>11){
		alert("password must more than 6 and less than 12");
	return false;
	}
	else if(password.length >12){
		alert("password must less than 12");
	return false;
	}
	if(img=="" ||img==null)
	{
	  alert("image must be selected ");
	return false;
	}
	if(age=="" ||age==null)
	{
	  alert("age must fill out ");
	return false;
	}
	if(license=="" ||license==null)
	{
	  alert("license must be fill out ");
	return false;
	}
	if(country=="" ||country==null)
	{
	  alert("country must fill out ");
	return false;
	}
	if(city=="" ||city==null)
	{
	  alert("city must fill out ");
	return false;
	}
	if(street=="" ||street==null)
	{
	  alert("street must fill out ");
	return false;
	}	  
	 
}
///////////////////////////////////////
function insertfolow()
{

	var happy=document.forms["myform"]["happy"].checked; 
	var lazy=document.forms["myform"]["lazy"].checked; 
	var sleep=document.forms["myform"]["sleep"].checked; 
	var quiet=document.forms["myform"]["quiet"].checked; 
	var teary=document.forms["myform"]["teary"].checked; 
	var angry=document.forms["myform"]["angry"].checked; 
	var attendant=document.getElementById("attendant");
	var absent=document.getElementById("absent"); 
 


	 
	
	 
	if( myform.student.selectedIndex==0)
	{
	alert("student  must be selected");
	myform.student.focus();
	return false;
	}
	if( myform.parent.selectedIndex==0)
	{
	  alert("parent  must be selected");
	  myform.parent.focus();
	return false;
	}
	 
	if( myform.route.selectedIndex==0)
	{
	alert("route  must be selected");
	myform.route.focus();
	return false;
	}
 
	if( myform.day.value=="")
	{
	alert("date  must be selected");
	myform.day.focus();
	return false;
	}
	if( attendant.checked == false && absent.checked == false)
	{
	alert("attend  must be selected");
 	return false;
	}

	if( myform.course_name.selectedIndex==0)
	{
	  alert("course  must be selected");
	  myform.course_name.focus();
	return false;
	}

	if( myform.home_worke.value=="")
	{
	  alert("home_worke  must be fill out");
	  myform.home_worke .focus();

 	return false;
	}

	if( myform.marks.value=="")
	{
	  alert("marks  must be fill out");
	  myform.marks.focus();

 	return false;
	}
	if( happy==false && lazy==false	&& sleep==false && quiet==false && teary==false && angry==false)
	{
	  alert("mode  must be selected one or more");
 
 	return false;
	}
	if( myform.activity.value=="")
	{
	  alert("activity  must be fill out");
	  myform.activity.focus();

 	return false;
	}
	alert("success");

	return true;

   }
   
 

  
 
   
   
   
   
