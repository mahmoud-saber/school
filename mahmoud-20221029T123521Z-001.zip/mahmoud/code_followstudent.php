<?php
include 'connected.php';
$student= $_SESSION['email'];
 
$sql="  SELECT * 
FROM `follow_up`,`stuent`,`course`
WHERE  idcourse=course_idcourse	AND idstuent=stuent_idstuent AND  
email_s='$student'";
$stmat=$conn->prepare($sql);
$stmat->execute();
 
 
  

 


 
?>