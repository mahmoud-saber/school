<?php
include 'connected.php';?>
 <?php
$parent = $_SESSION['email'];
//$dates = $_SESSION['date'];

 
 
$sql="SELECT *  FROM 
`follow_up`,`parent`,`stuent`,`course`,`route`WHERE 
idcourse=follow_up.course_idcourse 	AND idstuent=follow_up.stuent_idstuent	 AND 
idparent=follow_up.stuent_parent_idparent AND idroute=follow_up.stuent_route_idroute
AND idparent=stuent.parent_idparent AND idroute=stuent.route_idroute
AND email='$parent'";
$stmat=$conn->prepare($sql);
$stmat->execute();


 
?>