<?php
include 'connected.php';
$teacher = $_SESSION['email'];

$sql="  SELECT  course_name,career, time,section,dayname(dayss),dayname(day_off),username,class_room FROM 
`course`,`teacher`, `course_has_course_schedul`
WHERE  `idteacher`=`teacher_idteacher` AND `idcourse`=`course_idcourse` 
AND email='$teacher'
   ";

$stmat=$conn->prepare($sql);
$stmat->execute();
 while($row =$stmat->fetch(PDO::FETCH_ASSOC))
{
  
   
     $arr1[]=
         $row['course_name']."<br>";
         $arr2[]=
         $row['section']."<br>";
         $arr3[]=
         $row['time']."<br>";
         $arr4[]=
         $row['class_room']."<br>";

         $arr5[]=
         $row['dayname(dayss)']."<br>";
          
         $arr6[]=
         $row['dayname(day_off)']."<br>";

         $arr7[]=
         $row['username']."<br>";

         $arr8[]=
         $row['career']."<br>";


}
//print_r($arr8[0]);
//print_r($data);
/*\\print_r( $arr1);
echo "<br>";
print_r( $arr2);
echo "<br>";
print_r( $arr3);
echo "<br>";
print_r( $arr4);
echo "<br>";
print_r( $arr5);
echo "<br>";  
print_r( $arr6);
echo "<br>";  


 */
?>