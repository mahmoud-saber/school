<?php
include 'connected.php';
$parent = $_SESSION['email'];
$sql=" SELECT  course_name,class FROM 
`course_schedul`,`course`,`parent`,`stuent`, `course_has_course_schedul`
WHERE  `idparent`=`course_schedul`.`stuent_parent_idparent` AND idcourse=course_idcourse 
AND idparent=parent_idparent
AND `idparent`=`course_schedul_stuent_parent_idparent`  AND  email='$parent';
";
$stmat=$conn->prepare($sql);
$stmat->execute();
 while($row =$stmat->fetch(PDO::FETCH_ASSOC))
{
    $arr[]=
         $row['course_name'];
         $arr1[]=
         $row['class'];


}
//print_r( $arr[1]);
 
  

 


 
?>