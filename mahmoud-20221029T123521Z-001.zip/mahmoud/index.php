<?php include 'connected.php';?>
 <!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="x-ua-compatible" content="IE=9" /><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SCHOOL</title>
    <meta name="description" content="KIDS is a clean, modern, and fully responsive Html Template. Take your Startup business website to the next level. It is designed for kindergarten, childcare, homeschooling, school, learning, playground businesses or any type of person or business who wants to showcase their work, services and professional way.">
    <meta name="keywords" content="business, care, childcare, children, clean, corporate, happykids, homeschool, kids, kindergarten, playground, responsive, school, learning">
    <meta name="author" content="rometheme.net"> 
	
	<!-- ==============================================
	Favicons
	=============================================== -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
	
	<!-- ==============================================
	CSS VENDOR
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/vendor/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.theme.default.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/magnific-popup.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/animate.min.css">
	
	<!-- ==============================================
	Custom Stylesheet
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
    <script src="js/vendor/modernizr.min.js"></script>

</head>

<body>

	<!-- LOAD PAGE -->
	<div class="animationload">
		<div class="loader"></div>
	</div>
	
	<!-- BACK TO TOP SECTION -->
	<a href="#0" class="cd-top cd-is-visible cd-fade-out">Top</a>

	<!-- HEADER -->
    <div class="header header-1">

    	<!-- TOPBAR -->
    	<div class="topbar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-sm-8 col-md-6">
						<div class="info">
							<div class="info-item">
								<i class="fa fa-phone"></i> 01287950026
							</div>
							<div class="info-item">
								<i class="fa fa-envelope-o"></i> <a href="mailto:hagarhay@gmail.com" title="">school@gmail.com</a>
							</div>
						</div>
					</div>
					<div class="col-sm-4 col-md-6">
						<div class="sosmed-icon pull-right d-inline-flex">
							<a href="#" class="fb"><i class="fa fa-facebook"></i></a> 
							 
							<a href="#" class="ig"><i class="fa fa-instagram"></i></a> 
							
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- NAVBAR SECTION -->
		<div class="navbar-main" style="position: relative;">
			<div class="container">
			    <nav id="navbar-example" class="navbar navbar-expand-lg">
			        <a class="navbar-brand" href="index.php">
						<img src="images/school.jpg" alt="" width=200px height=90px>
					</a>
			        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
			            <span class="navbar-toggler-icon"></span>
			        </button>
			        <div class="collapse navbar-collapse" id="navbarNavDropdown">
			            <ul class="navbar-nav ml-auto">
			            	<li class="nav-item active">
			                    <a class="nav-link" href="index.php">HOME</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="registration.php">REGISTRATION</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="parents.php">PARENTS</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="teachers.php">TEACHERS</a>
							</li>
							<li class="nav-item">
			                    <a class="nav-link" href="students.php">STUDENTS</a>
							</li>
							<li class="nav-item">
			                    <a class="nav-link" href="drivers.php">DRIVERS</a>
			                </li>
			            	 
			            </ul>
			        </div>
			    </nav> <!-- -->

			</div>
		</div>

    </div>

	<!-- BANNER -->
    <div id="oc-fullslider" class="banner">
    	<div class="owl-carousel owl-theme full-screen">
	    	<div class="item">
	        	<img src="images/studnt.jpg" alt="Slider">
	        	<div class="overlay-bg"></div>
	        	<div class="container d-flex align-items-center">
	            	<div class="wrap-caption">
	            		<h4 class="caption-supheading" style="font-family: cursive; color: #fd4d40;">Welcome to School</h4>
		                <h1 class="caption-heading">Best students at any school</h1>
		                <!--<a href="#" class="btn btn-secondary">LEARN MORE</a>-->
		            </div>  
	            </div>
	    	</div>
	    	<div class="item">
	            <img src="images/teacher2.jpg" alt="Slider">
	            <div class="overlay-bg"></div>
	            <div class="container d-flex align-items-center">
	            	<div class="wrap-caption">
		                <h4 class="caption-supheading" style="font-family: cursive; color: #fd4d40;">Welcome to school</h4>
		                <h1 class="caption-heading">Best teachers at any school</h1>
		            </div>  
	            </div>
	        </div>  
	    	<div class="item">
	            <img src="images/parent2.jpg" alt="Slider"> 
	            <div class="overlay-bg"></div>
	            <div class="container d-flex align-items-center">
	            	<div class="wrap-caption">
		                <h4 class="caption-supheading" style="font-family: cursive; color: #fd4d40;">Welcome to school</h4>
		                <h1 class="caption-heading">Best parents for their child</h1>
		            </div>  
	            </div>
	        </div>  
    	</div>
	    <div class="custom-nav owl-nav"></div>
    </div>	

	<!-- WELCOME TO KIDS -->
	<div class="section">
		<div class="content-wrap">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12 col-lg-6">
						<img src="images/signup.jpg" style="
						width: 400px;
						height: 190px;" alt="" class="img-fluid img-border">
					</div>
					<div class="col-sm-12 col-md-12 col-lg-6">
						<h2 class="section-heading" style="font-family: cursive; color: #fd4d40;">
							Welcome to SCHOOL
						</h2>
						<p></p>
						<p></p>
						<div class="spacer-10"></div>
						<a href="registration.php" class="btn btn-secondary">SIGN UP</a>
						<div class="spacer-30"></div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- FUNFACT -->
	<div class="section bgi-overlay bgi-cover-center" data-background="images/school1.jpg">
		<div class="content-wrap">
			<div class="container">
				<div class="row">
					<!-- Item 1 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-primary">
							<div class="box-fun"><h2> <?php 
							$query="select * from stuent";
							$stmat=$conn->prepare($query);
							$stmat->execute();
							$rowcount=$stmat->rowCount($query);
							echo  $rowcount;?></h2></div>
							<div class="title">Students</div>	
						</div>
					</div>
					<!-- Item 2 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-secondary">
							<div class="box-fun"><h2><?php 
							$query="select * from teacher";
							$stmat=$conn->prepare($query);
							$stmat->execute();
							$rowcount=$stmat->rowCount($query);
							echo  $rowcount;?></h2></div>
											<div class="title">Teachers</div>	
						</div>
					</div>
					<!-- Item 3 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-tertiary">
							<div class="box-fun"><h2><?php 
							$query="select class from stuent";
							$stmat=$conn->prepare($query);
							$stmat->execute();
							$rowcount=$stmat->rowCount($query);
							echo  $rowcount;?></h2></div>
							<div class="title">Class Rooms</div>	
						</div>
					</div>
					<!-- Item 4 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-quaternary">
							<div class="box-fun"><h2><?php 
							$query="select * from bus";
							$stmat=$conn->prepare($query);
							$stmat->execute();
							$rowcount=$stmat->rowCount($query);
							echo  $rowcount;?></h2></div>
							<div class="title">Bus Schools</div>	
						</div>
					</div>
				</div>
			</div>
		</div> 
	</div>

	<!-- OUR GALLERY -->
	<div class="">
		<div class="content-wrap">
			<div class="container">

				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="supheading text-center">Our Image</p>
						<h2 class="section-heading text-center mb-5" style="font-family: cursive; color: #fd4d40;">
							Moment from SCHOOL
						</h2>
					</div>
				</div>
				
				<div class="row popup-gallery gutter-5">
					<!-- Item 1 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="images/st.jpg" title="Gallery #1">
								<img src="images/st.jpg" alt="" class="img-fluid" width="600px" height="400px">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 1 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="images/pr.jpg" title="Gallery #2" width="600px" height="400px">
								<img src="images/pr.jpg" alt="" class="img-fluid" width="600px" height="400px">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 1 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="images/teacherhome1.jpg" title="Gallery #3">
								<img src="images/teacherhome1.jpg" alt="" class="img-fluid" width="600px" height="400px">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 2 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="images/stg.jpg" title="Gallery #4">
								<img src="images/stg.jpg" alt="" class="img-fluid" width="600px" height="400px">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 3 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="images/stud.jpg" title="Gallery #5">
								<img src="images/stud.jpg" alt="" class="img-fluid" width="600px" height="400px">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 4 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="images/t.jpg" title="Gallery #6">
								<img src="images/t.jpg" alt="" class="img-fluid" width="600px" height="400px">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					
				</div>
				
			</div>
		</div>
	</div>

	<!-- CTA -->
	<div class="section bg-tertiary">
		<div class="content-wrap py-5">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-sm-12 col-md-12">
						<div class="cta-1">
			              	<div class="body-text mb-3">
			                	<h3 class="my-1 text-secondary">Let's join the best school now!</h3>
			              	</div>
			              	<div class="body-action">
			                	<a href="#" class="btn btn-primary mt-3">CONTACT US</a>
			              	</div>
			            </div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- FOOTER SECTION -->
	<div class="footer" style="background-color: #24a4c8;">
		<div class="content-wrap">
			<div class="container">
				
				<div class="row">
					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<img src="images/school.jpg" alt="logo bottom" class="logo-bottom" width=200px height=90px>
							<div class="spacer-30"></div>
						</div>
					</div>					

					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title" style="font-family: cursive;">
								Contact Info
							</div>
							<ul class="list-info">
								<li>
									<div class="info-icon">
										<span class="fa fa-map-marker"></span>
									</div>
									<div class="info-text">address</div> </li>
								<li>
									<div class="info-icon">
										<span class="fa fa-phone"></span>
									</div>
									<div class="info-text">01287950026</div>
								</li>
								<li>
									<div class="info-icon">
										<span class="fa fa-envelope"></span>
									</div>
									<div class="info-text">school@gmail.com</div>
								</li>
								<li>
									<div class="info-icon">
										<span class="fa fa-clock-o"></span>
									</div>
									<div class="info-text">time</div>
								</li>
							</ul>

						</div>
					</div>

					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title" style="font-family: cursive;">
								Useful Links
							</div>
							
							<ul class="list">
								<li><a href="registration.php" title="Our registration">Registration</a></li>
								<li><a href="teachers.php" title="Our Teacher">Teacher</a></li>
								<li><a href="students.php" title="Our students">Student</a></li>
								<li><a href="parents.php" title="Our parents">Parent</a></li>
								<li><a href="drivers.php" title=" Our drivers">Driver</a></li>
							</ul>
								
						</div>
					</div>
					
					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title" style="font-family: cursive;">
								Get in Touch
							</div>
							<div class="sosmed-icon d-inline-flex">
								<a href="#" class="fb"><i class="fa fa-facebook"></i></a> 
								<a href="#" class="ig"><i class="fa fa-instagram"></i></a> 
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="fcopy">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="ftex">Copyright 2020 &copy; <span class="color-primary">SCHOOL HTML Template</span>. Designed by <span class="color-primary">graduation project team.</span></p> 
					</div>
				</div>
			</div>
		</div>
		
	</div>
	
	<!-- JS VENDOR -->
	<script src="js/vendor/jquery.min.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/vendor/owl.carousel.js"></script>
	<script src="js/vendor/jquery.magnific-popup.min.js"></script>

	<!-- SENDMAIL -->
	<script src="js/vendor/validator.min.js"></script>
	<script src="js/vendor/form-scripts.js"></script>

	<script src="js/script.js"></script>

</body>
</html>