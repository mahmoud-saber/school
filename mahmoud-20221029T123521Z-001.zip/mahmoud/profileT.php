<?php 
include 'connected.php';
?>
<?php
session_start();

?>


 <!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="x-ua-compatible" content="IE=9" /><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SCHOOL Html Templates</title>
    <meta name="description" content="KIDS is a clean, modern, and fully responsive Html Template. Take your Startup business website to the next level. It is designed for kindergarten, childcare, homeschooling, school, learning, playground businesses or any type of person or business who wants to showcase their work, services and professional way.">
    <meta name="keywords" content="business, care, childcare, children, clean, corporate, happykids, homeschool, kids, kindergarten, playground, responsive, school, learning">
    <meta name="author" content="rometheme.net"> 
	
	<!-- ==============================================
	Favicons
	=============================================== -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
	
	<!-- ==============================================
	CSS VENDOR
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/vendor/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.theme.default.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/magnific-popup.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/animate.min.css">
	
	<!-- ==============================================
	Custom Stylesheet
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/style1.css">
	
    <script src="js/vendor/modernizr.min.js"></script>

</head>

<body>

	<!-- LOAD PAGE -->
	<div class="animationload">
		<div class="loader"></div>
	</div>
	
	<!-- BACK TO TOP SECTION -->
	<a href="#0" class="cd-top cd-is-visible cd-fade-out">Top</a>

	<!-- HEADER -->
    <div class="header header-1">

    	<!-- TOPBAR -->
    	<div class="topbar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-sm-8 col-md-6">
						<div class="info">
							<div class="info-item">
								<i class="fa fa-phone"></i> 01287950026
							</div>
							<div class="info-item">
								<i class="fa fa-envelope-o"></i> <a href="mailto:hagarhay@gmail.com" title="">school@gmail.com</a>
							</div>
						</div>
					</div>
					<div class="col-sm-4 col-md-6">
						<div class="sosmed-icon pull-right d-inline-flex">
							<a href="#" class="fb"><i class="fa fa-facebook"></i></a> 
							
							<a href="#" class="ig"><i class="fa fa-instagram"></i></a> 
							
							<a href="destroy_teacher.php" class="in"><i class="fa fa-lock"></i></a> 
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- NAVBAR SECTION -->
		<div class="navbar-main" style="position: relative;">
			<div class="container">
			    <nav id="navbar-example" class="navbar navbar-expand-lg">
			        <a class="navbar-brand" href="index.php">
						<img src="images/school.jpg" alt="" width=200px height=90px>
					</a>
			        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
			            <span class="navbar-toggler-icon"></span>
			        </button>
			        <div class="collapse navbar-collapse" id="navbarNavDropdown">
						<ul class="navbar-nav ml-auto">
			            	<li class="nav-item">
			                    <a class="nav-link" href="index.php">HOME</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="registration.php">REGISTRATION</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="parents.php">PARENTS</a>
			                </li>
			            	<li class="nav-item active">
			                    <a class="nav-link" href="teachers.php">TEACHERS</a>
							</li>
							<li class="nav-item">
			                    <a class="nav-link" href="students.php">STUDENTS</a>
							</li>
							<li class="nav-item">
			                    <a class="nav-link" href="drivers.php">DRIVERS</a>
			                </li>
			            </ul>
			        </div>
			    </nav> <!-- -->

			</div>
		</div>

    </div>

	<!-- BANNER -->
	<div class="section banner-page" data-background="images/regteacher.png">
		<div class="content-wrap pos-relative">
			<div class="d-flex justify-content-center bd-highlight mb-3">
				<div class="title-page" style="font-family: cursive;">Teachers</div>
			</div>
		</div>
	</div>

	<!-- forms -->
	<div class="center">
		<form method="POST" action="" id="" >
		<div class="card">
		  <div class="additional">
			<div class="user-card">
			  <div class="level center">
				Teacher
			  </div>

			<?php include ('pdo.php');?> 
			<?php
				$name='';
				if($pdoquery_run){
					while($row =$pdoquery_run->fetch(PDO::FETCH_OBJ))
					{
						?>
			<!--<div class="center"> <img src="upload/images/<?php //echo$row->image ?>" alt="" width="100px" height="100px"> </div>-->
			<div class="center"> <img src="upload/images/<?php echo trim( $row->image);?>"alt="" style="margin: 25px;" width="100px" height="100px"> </div>
			<title id="title">Teacher</title>
			</div>
			<div class="more-info">
 
			  <h1> <?php 
			  $name = $row->username;
			  echo $row->username;?> </h1>
			  <div class="coords">
				<span>Email : <?php echo 'E-mail ' . $row->email;?></span>
			  </div>
			  <div class="coords">
				<span>Gender : <?php echo $row->gender;?></span>
			  </div>
			  <div class="coords">
				<span>BirthDay : <?php echo $row->age;?></span>
			  </div>
			  <div class="coords">
				<span>career : <?php echo $row->career;?></span>
			  </div>
			  <div class="coords">
				<span>Address : <?php echo $row->country;?> : <?php echo $row->city;?> :<?php echo $row->street;?></span>
			  </div>
			  <?php
			}
			}
				else {
				echo '<script> alert("No registeration ") </script>' ;		
				}
	
			?>
			</div>
		  </div>

		  <div class="general">
			    <h1> <?php echo $name; ?></h1>
			<!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce a volutpat mauris, at molestie lacus. Nam vestibulum sodales odio ut pulvinar.</p>-->
			<span class="more">Mouse over the card for more info</span>
		  </div>
		</div>
	  </form>
	  </div>
	<!-- CTA -->
	<div class="section bg-tertiary">
		<div class="content-wrap py-5">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-sm-12 col-md-12">
						<div class="cta-1">
			              	<div class="body-text mb-3">
			                	<h3 class="my-1 text-secondary">Let's join the best school now!</h3>
			              	</div>
			              	<div class="body-action">
			                	<a href="contact.html" class="btn btn-primary mt-3">CONTACT US</a>
			              	</div>
			            </div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- FOOTER SECTION -->
	<div class="footer" style="background-color: #24a4c8;">
		<div class="content-wrap">
			<div class="container">
				
				<div class="row">
					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<img src="images/school.jpg" alt="logo bottom" class="logo-bottom" width=200px height=90px>
							<div class="spacer-30"></div>
						</div>
					</div>					

					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title" style="font-family: cursive;">
								Contact Info
							</div>
							<ul class="list-info">
								<li>
									<div class="info-icon">
										<span class="fa fa-map-marker"></span>
									</div>
									<div class="info-text">address</div> </li>
								<li>
									<div class="info-icon">
										<span class="fa fa-phone"></span>
									</div>
									<div class="info-text">01287950026</div>
								</li>
								<li>
									<div class="info-icon">
										<span class="fa fa-envelope"></span>
									</div>
									<div class="info-text">school@gmail.com</div>
								</li>
								<li>
									<div class="info-icon">
										<span class="fa fa-clock-o"></span>
									</div>
									<div class="info-text">time</div>
								</li>
							</ul>

						</div>
					</div>

					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title" style="font-family: cursive;">
								Useful Links
							</div>
							
							<ul class="list">
								<li><a href="registration.php" title="Our registration">Registration</a></li>
								<li><a href="teachers.php" title="Our Teacher">Teacher</a></li>
								<li><a href="students.php" title="Our students">Student</a></li>
								<li><a href="parents.php" title="Our parents">Parent</a></li>
								<li><a href="drivers.php" title=" Our drivers">Driver</a></li>
							</ul>
								
						</div>
					</div>
					
					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title" style="font-family: cursive;">
								Get in Touch
							</div>
							<div class="sosmed-icon d-inline-flex">
								<a href="#" class="fb"><i class="fa fa-facebook"></i></a> 
								<a href="#" class="ig"><i class="fa fa-instagram"></i></a> 
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="fcopy">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="ftex">Copyright 2020 &copy; <span class="color-primary">SCHOOL HTML Template</span>. Designed by <span class="color-primary">graduation project team.</span></p> 
					</div>
				</div>
			</div>
		</div>
		
	</div>
	
	<!-- JS VENDOR -->
	<script src="js/vendor/jquery.min.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/vendor/owl.carousel.js"></script>
	<script src="js/vendor/jquery.magnific-popup.min.js"></script>
	<script src="js/vendor/isotope.pkgd.min.js"></script>
	<script src="js/vendor/imagesloaded.pkgd.min.js"></script>

	<!-- SENDMAIL -->
	<script src="js/vendor/validator.min.js"></script>
	<script src="js/vendor/form-scripts.js"></script>

	<script src="js/script.js"></script>
	<script type="text/javascript" src="js/main1.js"></script>

</body>
</html>
