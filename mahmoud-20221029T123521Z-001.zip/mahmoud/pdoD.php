<?php 
include 'connected.php' ;
 
$driver = $_SESSION['email'];


$pdoquery="SELECT * FROM driver where email ='".$driver."'" ; /*add where condition yasta */ 

$pdoquery_run=$conn->query($pdoquery) ;



?>