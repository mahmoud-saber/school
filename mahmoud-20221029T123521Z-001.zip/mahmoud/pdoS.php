<?php 
include 'connected.php' ;
$student= $_SESSION['email'];
$pdoquery="  SELECT *
FROM `stuent` WHERE  `email_s`='$student'   " ;

$pdoquery_run=$conn->query($pdoquery) ;



?>