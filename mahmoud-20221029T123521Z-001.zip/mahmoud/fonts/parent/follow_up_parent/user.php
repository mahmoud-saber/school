<?php
class User{

    private $conn;

    public $idparent;
    public $idfollow_up;
    public $idcourse;
    public $email;
    public $password;
    public $date;
    public $activity;
    public $mode;
    public $attendant;
    public $marks;
    public $name;




    public function __construct($db){
        $this->conn = $db;
    }



     function follow(){


         $query = "SELECT * ,(SELECT Count(attendant) AS counte FROM `follow_up`) FROM `follow_up`,`parent`,`stuent`,`course`
         WHERE idcourse=`follow_up`.course_idcourse	 AND
           idparent=`follow_up`.stuent_parent_idparent AND idparent=stuent.parent_idparent
        AND
        parent.email='".$this->email."' AND parent.password='".$this->password."' ";

         $stmt = $this->conn->prepare($query);
         $stmt->execute();
        return $stmt;
    }

}
