<?php
 include_once 'database.php';
include_once 'user.php';

 $database = new Database();
$db = $database->getConnection();

 $user = new User($db);
 $user->email = isset($_POST['email']) ? $_POST['email'] : die(" ");
$user->password = sha1(isset($_POST['password']) ? $_POST['password'] : die(" "));

 $stmt = $user->follow();

if($stmt->rowCount() >0){
     while($row = $stmt->fetch(PDO::FETCH_ASSOC))
     {
     $user_arr[]=array(
        //"status" => true,
        //"message" => "Successfullyprofile",
        //"idfollow_up"=>$row['idfollow_up'],
        //"idstudent"=>$row['idstuent'],
        "username"=>$row['username'],
        "image" =>"/upload/images/".trim($row['image']),
        //"count_attentand"=>$row['(SELECT Count(attendant) AS counte FROM `follow_up`)'],
        "class_s"=>$row['class'],
        "idcourse"=>$row['idcourse'],
        "course"=>$row['course_name'],
        "date"=>$row['date'],
        "activity"=>$row['activity'],
        "mode"=>$row['mode'],
        "home_worke"=>$row['home_worke'],
        "attendant"=> $row['attendant'],
        "marks"=>$row['marks']);

    }



}else{
    $user_arr=array(
        "status" => false,
        "message" => "Invalid user or Password!",
    );
}
     echo json_encode($user_arr);

?>
