<?php
class User{


   private $conn;
   public $idteacher;
   public $image;
   public $username;
   public $career;



    public function __construct($db){
        $this->conn = $db;
    }

    function schudel(){
          $query = " SELECT career,idteacher,image,username FROM  teacher";
         $stmt = $this->conn->prepare($query);
         $stmt->execute();
        return $stmt;
    }

}
