<?php
class User{
 
 
   private $conn;
   public $serialnumber;
   public $time;
   public $day;
   public $name;
   public $stuent_idstuent;
   public $stuent_route_idroute;
   public $stuent_parent_idparent;



  
    public function __construct($db){
        $this->conn = $db;
    }
     
    function schudel(){
          $query = "  SELECT  * FROM 
          `course_schedul`,`course`,`parent`,`stuent`, `course_has_course_schedul`
          WHERE  `idparent`=`stuent_parent_idparent`  AND idcourse=course_idcourse  
           AND  `idstuent`=`course_has_course_schedul`.`course_schedul_stuent_idstuent`
          AND idcourse=`course_has_course_schedul`.course_idcourse AND
		`course_schedul`.serialnumber=`course_has_course_schedul`.course_schedul_serialnumber 
          AND 
        `parent`.`email`='".$this->email."' AND `parent`.password='".$this->password."' ";
        
         $stmt = $this->conn->prepare($query);
         $stmt->execute();
        return $stmt;
    }
    
}