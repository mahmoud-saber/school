<?php
include 'connectdb.php';
header('content-type:application/json');

$usernam=$_POST['usernam'];
$email=$_POST['email'];
$password= sha1( $_POST['password']);
$gender=$_POST['gender'];
$phone=$_POST['phone'];
 $sql="INSERT INTO `parent` (`usernam`,`email` ,`password`,`gender`)
    VALUES('$usernam','$email','$password','$gender');
    INSERT INTO `parentphone`(`phone`,`parent_idparent`) VALUE('$phone',
     (SELECT idparent FROM `parent` WHERE email='$email')) ";
    //$result=mysqli_query($conn,$sql);
   $result=$conn->prepare($sql);
    $result ->execute();
    if($result)
    {

        $data=array(
            "status"=>"true",
            "username"=>strval($usernam),
            "email"=>strval($email),
            "password"=>strval($password),
            "gender"=>strval($gender),
            "phone_number"=>strval($phone)

        );
     }
    else
    {
        echo "NOT insert" ;
    }
    echo json_encode($data);
  ?>
