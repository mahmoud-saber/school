<?php
class User{
 
    // database connection and table name
    private $conn;
   // private $table_name = "teacher";
    //private $table_name1="teacherphone";
 
    // object properties
    public $idparent;
    public $usernam;
    public $email;
    public $password;
    public $gender;
    public $phone;
   


  
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
     
    
    // login user
    function profile(){
        // select all query
        $query = " SELECT `idparent`, `parent`.`usernam`,`parent`.`email`,`parent`.`password`,`parent`.`gender`,
      `parentphone`.`phone`,
      `stuent`.`idstuent`, `stuent`.`username`,`stuent`.`email_s`,`stuent`.`image` ,`stuent`.`age` ,`stuent`.`gender_s`, `stuent`.`class` ,`stuent`.`country`,
      `stuent`.`city` ,`stuent`.`street`  
      FROM `parent` ,`parentphone`,`stuent` 
      WHERE `parent`.idparent=`parentphone`.parent_idparent 
      AND`parent`.idparent= `stuent`.`parent_idparent` AND  
        `parent`.email='".$this->email."' AND `parent`.password='".$this->password."' ";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        // execute query
        $stmt->execute();
        return $stmt;
    }
    
}