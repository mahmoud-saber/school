<?php
 include 'connected.php';

if(isset($_POST['Submit'])){
    $filename=$_FILES['image']['name'];
    $filesize=$_FILES['image']['size'];
    $filetmp_name=$_FILES['image']['tmp_name'];
    $filetype=$_FILES['image']['type'];
    $imagAllowExtension=array("jpeg","png","jpg","gif");
    @$imagExtension=strtolower(end(explode('.',  $filename)));
    $username=$_POST['username'];
    $email_s=$_POST['email_s'];
    $password= sha1( $_POST['password']);
     $age=$_POST['age'];
    $class=$_POST['class'];
    $gender=$_POST['gender_s'];
    $country=$_POST['country'];
    $city=$_POST['city'];
    $street=$_POST['street'];
    $emialparent=$_POST['email'];
    $name=$_POST['name'];

    $formErrors=array();
    if(strlen($username)<4)
    {
        $formErrors[]='Username Cant Be Less Than<strong>4 Characters</strong>';
    }
    if(strlen($username)>20)
    {
        $formErrors[]='Username Cant Be More Than <strong>20 Characters</strong>';
    }
    if(empty($username))
    {
        $formErrors[]='Username Cant Be  <strong> Empty</strong>';
    }
    if(empty($email_s))
    {
        $formErrors[]='Email Cant Be  <strong> Empty</strong>';
    }
    if(empty($password))
    {
        $formErrors[]='Password Cant Be  <strong> Empty</strong>';
    }
    if(empty($age))
    {
        $formErrors[]='age Cant Be  <strong> Empty</strong>';
    }
    if(empty($class))
    {
        $formErrors[]='Class Cant Be  <strong> Empty</strong>';
    }
    if(empty($gender))
    {
        $formErrors[]='Gender Cant Be  <strong> Empty</strong>';
    }
    if(empty($country))
    {
        $formErrors[]='Country Cant Be  <strong> Empty</strong>';
    }
    if(empty($city))
    {
        $formErrors[]='City Cant Be  <strong> Empty</strong>';
    }
    if(empty($street))
    {
        $formErrors[]='Street Cant Be  <strong> Empty</strong>';
    }
    if(empty($emialparent))
    {
        $formErrors[]='EmailParent Cant Be  <strong> Empty</strong>';
    }
    if(empty($name))
    {
        $formErrors[]='RouteName Cant Be  <strong> Empty</strong>';
    }
    if(empty($filename))
    {
        $formErrors[]='Image Is  <strong> Requert</strong>';
    }
    if(empty($filename) && ! in_array($imagExtension,$imagAllowExtension))
    {
        $formErrors[]='Extension Is Not <strong> Allow</strong>';
    }
    /*if(empty($filesize < 104857600))
    {
        $formErrors[]='Image Cant Be  <strong> 60M</strong>';
    }*/
    
    
    foreach($formErrors as $error){ echo '<div class="alert alert-danger">'.$error.'</div>';}

    if(empty($formErrors))
    {
        $avatar=rand(0,100000000).'_'.$filename;
        move_uploaded_file($filetmp_name,"upload/images/".$avatar);    
    
  try{
        $conn->beginTransaction();
        $stmt= $conn->exec("INSERT INTO `route`(`name`)VALUES('$name');
        INSERT INTO `stuent` (`username`, `email_s`, `password`,`image`,`age`,
         `class`, `gender_s`, `country`, `city`, `street`,`parent_idparent`,`route_idroute`)
         VALUES('$username','$email_s','$password','$avatar','$age','$class',
         '$gender','$country','$city','$street',(SELECT idparent FROM `parent` WHERE email='$emialparent'),
         (SELECT idroute FROM `route` WHERE name='$name'))");
           
        $stmt= $conn->exec("INSERT INTO `course_schedul`(`stuent_idstuent`,`stuent_parent_idparent`,
        `stuent_route_idroute`)VALUE ((SELECT idstuent FROM `stuent` WHERE email_s='$email_s'),
        (SELECT idparent FROM `parent` WHERE email='$emialparent'),
        (SELECT idroute FROM `route` WHERE name='$name')) ");  
        $conn->commit();

      }
      catch(Exception $e){
        echo $e->getMessage();
        $conn->rollBack();
    }
    header('Location: students.php');

    }
}
else{
    echo "invaled";
}

     
