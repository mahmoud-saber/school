<?php
 include_once 'database.php';
include_once 'user.php';
 
 $database = new Database();
$db = $database->getConnection();
 
 $user = new User($db);
 $user->email = isset($_POST['email']) ? $_POST['email'] : die(" ");
$user->password = sha1(isset($_POST['password']) ? $_POST['password'] : die(" "));
 $stmt = $user->trip();
if($stmt->rowCount() > 0){
     
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // create array
    $user_arr=array(
        "idstuent" => $row['idstuent'],
        "username" => $row['username'],
        "email_student" => $row['email_s'],
         
     );
     
     
}
else{
        $user_arr=array(
            "status" => false,
            "message" => "Invalid user or Password!",
    );
}
     print_r(json_encode($user_arr));
?>