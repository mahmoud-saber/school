<?php
class Database{
 
    // specify your own database credentials
    private $host = "localhost";
    private $db_name = "id14438335_final2021";
    private $username = "id14438335_final";
    private $password = "=co8DhRGlRVvQ?AQ";
    public $conn;
 
    // get the database connection
    public function getConnection(){
 
        $this->conn = null;
 
        try{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
            //echo "connection is successful";
        }catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
        }
 
        return $this->conn;
    }
}
?>