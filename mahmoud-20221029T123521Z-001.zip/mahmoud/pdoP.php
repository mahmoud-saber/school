<?php 
include 'connected.php' ;

$parent = $_SESSION['email'];
$pdoquery="  SELECT *
FROM `parent`,`stuent` WHERE `idparent`=`parent_idparent`    
AND email='$parent'   " ;

$pdoquery_run=$conn->query($pdoquery) ;



?>