<?php

session_start(); 
session_destroy(); 
header("location:teachers.php"); 
exit();
?>