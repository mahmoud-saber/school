<?php 

include 'connected.php';
session_start();
?>
<?php 
  if(isset($_POST['login'])){
$sql = "select email,password,date from parent,`follow_up`";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll();

foreach ($result as $row) {
if($row[0] == $_POST['email'] && $row[1] == sha1( $_POST['password'])){

  $_SESSION['email'] = $_POST['email'];
 // $_SESSION['date'] = $_POST['date'];

 

  header('Location:allParent.php');
  exit();
}
else{
   header('Location:page-404.php');
    }

}

} 

?>