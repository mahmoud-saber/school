<?php
class User{

     private $conn;
  public $idparent;
    public $username;
    public $usernam;
    public $image;

     public function __construct($db){
        $this->conn = $db;
    }


     function chat(){
         $query = "SELECT `idparent`,`username`,`usernam`,`image` FROM `parent`,`stuent`
         WHERE parent_idparent= idparent
         ";
         $stmt = $this->conn->prepare($query);
         $stmt->execute();
        return $stmt;
    }

}
