<?php
 include_once 'database.php';
include_once 'user.php';

 $database = new Database();
$db = $database->getConnection();

 $user = new User($db);
 $stmt = $user->chat();
if($stmt->rowCount() > 0){
    while( $row = $stmt->fetch(PDO::FETCH_ASSOC)){
     $user_arr[]=array(
      //  "status" => true,
       // "message" => "Successfully Login!",
       "idparent"=>$row['idparent'],
        "username_parent"=>$row['usernam'],
        "username_seudent" => $row['username'],
        "image" =>"/upload/images/".trim( $row['image']
      )
    )
    ;



 }
   print_r(json_encode($user_arr));

}else{
    $user_arr=array(
        "status" => false,
        "message" => "Invalid user or Password!",
    );

}
?>
