 <?php
 include 'connectdb.php';
header('content-type:application/json');
  $date=$_POST['date'];
 $activity=  $_POST['activity'];
 $marks=$_POST['marks'];
 $attendant=$_POST['attendant'];
 @$ckeck_mode=$_POST['mode'];
 @$mode=implode(',',$ckeck_mode);
  $home_worke=$_POST['home_worke'];
 $coursename=$_POST['course_name'];
 $route_name=$_POST['name'];
 $eparent=$_POST['email'];
 $emails=$_POST['email_s'];

 $sql=" INSERT INTO `follow_up`( `date`, `activity`, `marks`, `attendant`,
  `mode`,`home_worke`, `course_idcourse`,
  `stuent_idstuent`, `stuent_parent_idparent`, `stuent_route_idroute`) VALUES ('$date',
  '$activity','$marks','$attendant','$mode','$home_worke',
  (SELECT idcourse FROM `course` WHERE course_name='$coursename' ),
   (SELECT idstuent FROM `stuent` WHERE email_s='$emails'),
   (SELECT idparent FROM `parent` WHERE email='$eparent'),
   (SELECT idroute FROM `route` WHERE name='$route_name'))";
    //$result=mysqli_query($conn,$sql);
   $result=$conn->prepare($sql);
    $result ->execute();
    if($result)
    {

        $data=array(
           "status"=>"true",
            "message"=>"successful insert",
            "email"=>"$eparent",
            "email_s"=>$emails,
            "name"=>$route_name,
            "course"=>$coursename,
            "datee"=>$date,
            "activity"=>$activity,
            "marks"=>$marks,
            "attendant"=>$attendant,
            "mode"=>$mode,
            "home_worke"=>$home_worke


        );
        echo json_encode($data);

     }
    else
    {
        echo "NOT insert" ;
    }
  ?>
