  <?php

 include 'connectdb.php';

header('content-type:application/json');





$filename=$_FILES ['image']['name'];

$filesize=$_FILES ['image']['size'];

$filetmp_name=$_FILES ['image']['tmp_name'];

$filetype=$_FILES ['image']['type'];

$imagAllowExtension=array("jpeg","png","jpg","gif");

//$imagExtension=end(explode('.',$filename));

$username=$_POST['username'];

$email=$_POST['email'];

$password= sha1( $_POST['password']);

 $age=$_POST['age'];

$gender=$_POST['gender'];

$career=$_POST['career'];

$country=$_POST['country'];

$city=$_POST['city'];

$street=$_POST['street'];

$phone=$_POST['phone'];







if(empty($formErrors))

{

    $avatar=rand(0,100000000).'_'.$filename;

    move_uploaded_file($filetmp_name,"../../upload/images/".$avatar);

    $stmt = $conn->prepare("INSERT INTO `teacher` (username, email ,password,age,gender,career,country,city,street,image)

    VALUES('$username','$email','$password','$age','$gender','$career','$country','$city','$street','$avatar');
 INSERT INTO `teacherphone`(phone,teacher_idteacher) VALUE ('$phone',(SELECT idteacher FROM teacher WHERE email='$email'))");



     $stmt->bindParam(':username', $username,PDO::PARAM_STR);

       $stmt->bindParam(':email',$email,PDO::PARAM_STR);

       $stmt->bindParam(':password', $password,PDO::PARAM_INT);

       $stmt->bindParam(':image',$avatar,PDO::PARAM_STR);

       $stmt->bindParam(':gender',$gender,PDO::PARAM_STR);

       $stmt->bindParam(':career',$career,PDO::PARAM_STR);

       $stmt->bindParam(':country',$country,PDO::PARAM_STR);

       $stmt->bindParam(':city',$city,PDO::PARAM_STR);

       $stmt->bindParam(':street',$street,PDO::PARAM_STR);

      $stmt->bindParam(':phone',$phone,PDO::PARAM_INT);



       $stmt->execute();

}

    if($stmt)

    {



        $data=array(

            "status"=>"true",

            "username"=>$username,

            "email"=>$email,

            "password"=>$password,

            "image"=>"/upload/images/".$avatar,

            "age"=>$age,

            "gender"=>$gender,

            "career"=>$career,

            "country"=>$country,

            "city"=>$city,

            "street"=>$street,

            "phone"=>$phone,



        );

     }

    else

    {

        echo "NOT insert" ;

    }

    echo json_encode($data);

  ?>

