<?php
class User{


   private $conn;
   public $serialnumber;
   public $time;
   public $day;
   public $name;
   public $stuent_idstuent;
   public $stuent_route_idroute;
   public $stuent_parent_idparent;




    public function __construct($db){
        $this->conn = $db;
    }

    function schudel(){
          $query = " SELECT  course_name, section,dayname(dayss),dayname(day_off),username,class_room ,time FROM
          `course`,`teacher`, `course_has_course_schedul`
          WHERE  `idteacher`=`teacher_idteacher` AND `idcourse`=`course_idcourse`
          AND
        `teacher`.`email`='".$this->email."' AND `teacher`.password='".$this->password."' ";

         $stmt = $this->conn->prepare($query);
         $stmt->execute();
        return $stmt;
    }

}
