<?php
// include database and object files
include_once 'database.php';
include_once 'user.php';

// get database connection
$database = new Database();
$db = $database->getConnection();

// prepare user object
$user = new User($db);
// set ID property of user to be edited
$user->email = isset($_POST['email']) ? $_POST['email'] : die(" ");
$user->password = sha1(isset($_POST['password']) ? $_POST['password'] : die(" "));
 $stmt = $user->schudel();
if($stmt->rowCount() > 0){

  while( $row = $stmt->fetch(PDO::FETCH_ASSOC)){

     $user_arr[]=array(
        "status" => true,
        "message" => "Successfullyprofile",
        //"serialnumber" => $row['serialnumber'],
        "dayss" => $row['dayname(dayss)'],
        "day_off" =>$row['dayname(day_off)'],
        "class_room" =>$row['class_room'],
        //"solt" =>$row['solt'],
        "section" =>$row['section'],
        "time" =>$row['time'],
        "username" =>$row['username'],
          "cousrename" =>$row['course_name'],



        //"stuent_idstuent"=>$row['stuent_idstuent'],
        //"stuent_parent_idparent"=>$row['stuent_parent_idparent'],
        //"stuent_route_idroute"=>$row['stuent_route_idroute']
       );
     }
     echo json_encode($user_arr);

}
else{
        $user_arr=array(
            "status" => false,
            "message" => "Invalid user or Password!",
    );
}

?>
