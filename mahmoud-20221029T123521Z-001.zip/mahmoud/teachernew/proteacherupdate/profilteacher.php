<?php
// include database and object files
include_once 'database.php';
include_once 'user.php';

// get database connection
$database = new Database();
$db = $database->getConnection();

// prepare user object
$user = new User($db);
// set ID property of user to be edited
$user->email = isset($_POST['email']) ? $_POST['email'] : die(" ");
$user->password = sha1(isset($_POST['password']) ? $_POST['password'] : die(" "));
// read the details of user to be edited
$stmt = $user->profile();
if($stmt->rowCount() > 0){
    /*while($row = $stmt->fetch(PDO::FETCH_ASSOC))
    {
      echo json_encode( "<a href='web/upload/images/".$row['image']."'></a>");
    }
    */
    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // create array

     $user_arr=array(
        "status" => true,
        "message" => "Successfullyprofile",
        "idteacher" => $row['idteacher'],
        "username" => $row['username'],
        "email" => $row['email'],
        "image"=>"/upload/images/".trim($row['image']),
         "age" => $row['age'],
        "gender" => $row['gender'],
        "career" => $row['career'],
        "phone" => $row['phone'],
        "country" => $row['country'],
        "city" => $row['city'],
        "street" => $row['street']
     );

}else{
    $user_arr=array(
        "status" => false,
        "message" => "Invalid user or Password!",
    );
}

// make it json format
   print_r(json_encode($user_arr));
?>
