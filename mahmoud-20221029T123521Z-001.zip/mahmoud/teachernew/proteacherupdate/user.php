<?php
class User{

    // database connection and table name
    private $conn;
   // private $table_name = "teacher";
    //private $table_name1="teacherphone";

    // object properties
    public $idteacher;
    public $username;
    public $email;
    public $password;
    public $image;
    public $age;
    public $gender;
    public $career;
    public $phone;
    public $country;
    public $city;
    public $street;



    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }


    // login user
    function profile(){
        // select all query
        $query = "SELECT
                    *
                FROM
                `teacher` ,`teacherphone`
                WHERE
                `teacher`.idteacher=`teacherphone`.teacher_idteacher AND
                    email='".$this->email."' AND password='".$this->password."' ";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        // execute query
        $stmt->execute();
        return $stmt;
    }

}
