<?php
class User{
 
    private $conn;
    
    public $idstuent;
    public $username;
    public $email_s;
    public $class;
    public $image;
    public $name;
    public $idparent;
    public $usernam;
    public $email;
   

  
     public function __construct($db){
        $this->conn = $db;
    }
     
    
     function follow(){
         $query = " SELECT idstuent,username,email_s,image,class,idroute,name,idparent,usernam,email
        FROM `stuent`,`parent`,`route`
        WHERE `parent`.`idparent`= `stuent`.`parent_idparent`
         AND  `route`.`idroute`=`stuent`.`route_idroute` ";
         $stmt = $this->conn->prepare($query);
         $stmt->execute();
        return $stmt;
    }
    
}