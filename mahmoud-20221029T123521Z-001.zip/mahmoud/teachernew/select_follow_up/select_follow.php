<?php
 include_once 'database.php';
include_once 'user.php';
header('Content-Type:application/json');
 $database = new Database();
$db = $database->getConnection();

 $user = new User($db);
 $stmt = $user->follow();
if($stmt->rowCount() > 0){

     while($row = $stmt->fetch(PDO::FETCH_ASSOC)){

     $user_arr[]=array(
         "idstuent" => $row['idstuent'],
        "username_student" => $row['username'],
        "email_student" => $row['email_s'],
        "image"=>"/upload/images/".trim($row['image']),
         "class_s" => $row['class'],
        "idparent" => $row['idparent'],
        "username_parent" => $row['usernam'],
        "email" => $row['email'],
        "idroute" => $row['idroute'],
        "route_name" => $row['name'] );

     }



}else{
    $user_arr=array(
        "status" => false,
        "message" => "Invalid user or Password!",
    );
    print_r(json_encode($user_arr));

}

    print_r(json_encode($user_arr));
?>
