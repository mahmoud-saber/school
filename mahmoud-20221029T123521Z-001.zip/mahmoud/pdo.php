<?php 
include 'connected.php' ;

$teacher = $_SESSION['email'];


$pdoquery="SELECT * FROM teacher where email ='".$teacher."'" ; /*add where condition yasta */ 

$pdoquery_run=$conn->query($pdoquery) ;



?>