<?php 
include 'connected.php' ;

$em = $_SESSION['email'];


$pdoquery="SELECT * FROM teacher where email ='".$em."'" ; /*add where condition yasta */ 

$pdoquery_run=$conn->query($pdoquery) ;



?>