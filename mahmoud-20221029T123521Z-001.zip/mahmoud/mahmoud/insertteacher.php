<?php
 include 'connected.php'?>
<?php
if(isset($_POST['Submit'])){
    $filename=$_FILES ['image']['name'];
    $filesize=$_FILES ['image']['size'];
    $filetmp_name=$_FILES ['image']['tmp_name'];
    $filetype=$_FILES ['image']['type'];
    $imagAllowExtension=array("jpeg","png","jpg","gif");
    $imagExtension=end(explode('.',$filename));


    $username=$_POST['username'];
    $email=$_POST['email'];
    $password= sha1( $_POST['password']);
     $age=$_POST['age'];
    $gender=$_POST['gender'];
    $career=$_POST['career'];
    $country=$_POST['country'];
    $city=$_POST['city'];
    $street=$_POST['street'];
    $phone=$_POST['phone'];

    $formErrors=array();
    if(strlen($username)<4)
    {
        $formErrors[]='Username Cant Be Less Than<strong>4 Characters</strong>';
    }
    if(strlen($username)>20)
    {
        $formErrors[]='Username Cant Be More Than <strong>20 Characters</strong>';
    }
    if(empty($username))
    {
        $formErrors[]='Username Cant Be  <strong> Empty</strong>';
    }
    if(empty($email))
    {
        $formErrors[]='Email Cant Be  <strong> Empty</strong>';
    }
    if(empty($password))
    {
        $formErrors[]='Password Cant Be  <strong> Empty</strong>';
    }
    if(empty($age))
    {
        $formErrors[]='age Cant Be  <strong> Empty</strong>';
    }
     
    if(empty($gender))
    {
        $formErrors[]='Gender Cant Be  <strong> Empty</strong>';
    }
    if(empty($country))
    {
        $formErrors[]='Country Cant Be  <strong> Empty</strong>';
    }
    if(empty($city))
    {
        $formErrors[]='City Cant Be  <strong> Empty</strong>';
    }
    if(empty($street))
    {
        $formErrors[]='Street Cant Be  <strong> Empty</strong>';
    }
     
     
    if(empty($filename))
    {
        $formErrors[]='Image Is  <strong> Requert</strong>';
    }
    if(empty($filename) && ! in_array($imagExtension,$imagAllowExtension))
    {
        $formErrors[]='Extension Is Not <strong> Allow</strong>';
    }
    /*if(empty($filesize < 104857600))
    {
        $formErrors[]='Image Cant Be  <strong> 60M</strong>';
    }
    */

    foreach($formErrors as $error){ echo '<div class="alert alert-danger">'.$error.'</div>';}

    if(empty($formErrors))
    {
        $avatar=rand(0,100000000).'_'.$filename;
         move_uploaded_file($filetmp_name,"upload/images\\".$avatar);
     
     
  
  $stmt = $conn->prepare("INSERT INTO `teacher` (username, email ,password,image,age,gender,
  career,country,city,street) 
  VALUES('$username','$email','$password',' $avatar','$age','$gender','$career',
    '$country','$city','$street');
     INSERT INTO `teacherphone`(phone,teacher_idteacher) VALUE ('$phone',(SELECT idteacher FROM teacher WHERE email='$email'))");

   $stmt->bindParam(':username', $username,PDO::PARAM_STR);
     $stmt->bindParam(':email',$email,PDO::PARAM_STR);
     $stmt->bindParam(':password', $password,PDO::PARAM_INT);
     //$stmt->bindParam(':image',$avatar,PDO::PARAM_STR);
     $stmt->bindParam(':gender',$gender,PDO::PARAM_STR);
     $stmt->bindParam(':career',$career,PDO::PARAM_STR);
     $stmt->bindParam(':country',$country,PDO::PARAM_STR);
     $stmt->bindParam(':city',$city,PDO::PARAM_STR);
     $stmt->bindParam(':street',$street,PDO::PARAM_STR);
    $stmt->bindParam(':phone',$phone,PDO::PARAM_INT);

     $stmt->execute();

     
    }
    header('Location: teachers.php');

}
else{
    echo "invaled";
}


?>