<?php
include 'connected.php';
$sql=" SELECT *  FROM 
`follow_up`,`parent`,`stuent`,`course`
WHERE 
idcourse=course_idcourse 	AND idstuent=stuent_idstuent	 AND 
idparent=stuent_parent_idparent AND email='saber@gmail.com'";
$stmat=$conn->prepare($sql);
$stmat->execute();
 
?>