<?php
 include 'connected.php';

if(isset($_POST['Submit'])){
    $filename=$_FILES['image']['name'];
    $filesize=$_FILES['image']['size'];
    $filetmp_name=$_FILES['image']['tmp_name'];
    $filetype=$_FILES['image']['type'];
    $imagAllowExtension=array("jpeg","png","jpg","gif");
    $imagExtension=strtolower(end(explode('.',  $filename)));

    $username=$_POST['username'];
    $email=$_POST['email_s'];
    $password= sha1( $_POST['password']);
     $age=$_POST['age'];
    $class=$_POST['class'];
    $gender=$_POST['gender_s'];
    $country=$_POST['country'];
    $city=$_POST['city'];
    $street=$_POST['street'];
    $emilparent=$_POST['email'];
    $name=$_POST['name'];

    $formErrors=array();
    if(strlen($username)<4)
    {
        $formErrors[]='Username Cant Be Less Than<strong>4 Characters</strong>';
    }
    if(strlen($username)>20)
    {
        $formErrors[]='Username Cant Be More Than <strong>20 Characters</strong>';
    }
    if(empty($username))
    {
        $formErrors[]='Username Cant Be  <strong> Empty</strong>';
    }
    if(empty($email))
    {
        $formErrors[]='Email Cant Be  <strong> Empty</strong>';
    }
    if(empty($password))
    {
        $formErrors[]='Password Cant Be  <strong> Empty</strong>';
    }
    if(empty($age))
    {
        $formErrors[]='age Cant Be  <strong> Empty</strong>';
    }
    if(empty($class))
    {
        $formErrors[]='Class Cant Be  <strong> Empty</strong>';
    }
    if(empty($gender))
    {
        $formErrors[]='Gender Cant Be  <strong> Empty</strong>';
    }
    if(empty($country))
    {
        $formErrors[]='Country Cant Be  <strong> Empty</strong>';
    }
    if(empty($city))
    {
        $formErrors[]='City Cant Be  <strong> Empty</strong>';
    }
    if(empty($street))
    {
        $formErrors[]='Street Cant Be  <strong> Empty</strong>';
    }
    if(empty($emilparent))
    {
        $formErrors[]='EmailParent Cant Be  <strong> Empty</strong>';
    }
    if(empty($name))
    {
        $formErrors[]='RouteName Cant Be  <strong> Empty</strong>';
    }
    if(empty($filename))
    {
        $formErrors[]='Image Is  <strong> Requert</strong>';
    }
    if(empty($filename) && ! in_array($imagExtension,$imagAllowExtension))
    {
        $formErrors[]='Extension Is Not <strong> Allow</strong>';
    }
    /*if(empty($filesize < 104857600))
    {
        $formErrors[]='Image Cant Be  <strong> 60M</strong>';
    }*/
    
    
    foreach($formErrors as $error){ echo '<div class="alert alert-danger">'.$error.'</div>';}

    if(empty($formErrors))
    {
        $avatar=rand(0,100000000).'_'.$filename;
        move_uploaded_file($filetmp_name,"upload\images\\".$avatar);
     
    
 //insert into ))
 try{
        $conn->beginTransaction();
       $stmt= $conn->exec("INSERT INTO `route`(`name`)VALUES('$name');
       INSERT INTO `stuent` (`username`, `email_s`, `password`,`image`,`age`,
        `class`, `gender_s`, `country`, `city`, `street`,`parent_idparent`,`route_idroute`)
        VALUES('$username','$email','$password','$avatar','$age','$class',
        '$gender','$country','$city','$street',(SELECT idparent FROM `parent` WHERE email='$emilparent'),
        (SELECT idroute FROM `route` WHERE name='$name'))");

    $stmt= $conn->exec("INSERT INTO `course_schedul`(`stuent_idstuent`,`stuent_parent_idparent`,
     `stuent_route_idroute`)
        VALUE ((SELECT idstuent FROM `stuent` WHERE email_s='$email'),
        (SELECT idparent FROM `parent` WHERE email='$emilparent'),
        (SELECT idroute FROM `route` WHERE name='$name')) ");


/*$stmt= $conn->exec("INSERT INTO `course_has_course_schedul`(`course_idcourse`,`course_schedul_serialnumber`,
`course_schedul_stuent_idstuent`,`course_schedul_stuent_parent_idparent`,`course_schedul_stuent_route_idroute`,
teacher_idteacher)
   VALUE ((SELECT idcourse FROM `course` WHERE `idstuent`=`stuent_idstuent`  AND email_s='$email'),
   (SELECT `serialnumber` FROM `course_schedul` WHERE `stuent_idstuent`=`idstuent`),
   (SELECT `idstuent` FROM `stuent`  WHERE email_s='$email'),
   (SELECT idparent FROM `parent` WHERE email='$emilparent'),
   (SELECT idroute FROM `route` WHERE name='$name'))");*/
        $conn->commit();
   
    }
    catch(Exception $e){
        echo $e->getMessage();
        $conn->rollBack();
    }
}
    header('Location: students.php');

}
else{
    echo "invaled";
}
/*$stmt->bindParam(':username', $username,PDO::PARAM_STR );
     $stmt->bindParam(':email',$email ,PDO::PARAM_STR );
     $stmt->bindParam(':password' ,$password,PDO::PARAM_STR );
    // $stmt->bindParam(':image',$avatar, PDO::PARAM_STR) ;
     $stmt->bindParam(':age',$age,PDO::PARAM_STR  );
     $stmt->bindParam(':gender',$gender,PDO::PARAM_STR  );
     $stmt->bindParam(':country',$country,PDO::PARAM_STR  );
     $stmt->bindParam(':city',$city,PDO::PARAM_STR  );
     $stmt->bindParam(':street',$street,PDO::PARAM_STR );
 */
     
?>