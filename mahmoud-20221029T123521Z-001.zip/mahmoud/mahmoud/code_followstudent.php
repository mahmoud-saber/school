<?php
include 'connected.php';
$sql="  SELECT * 
FROM `follow_up`,`stuent`,`course`
WHERE  idcourse=course_idcourse	AND idstuent=stuent_idstuent AND  
email_s='mohsen@gmail.com'";
$stmat=$conn->prepare($sql);
$stmat->execute();
 
 
  

 


 
?>