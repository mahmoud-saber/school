<?php
include 'connected.php';
$sql=" SELECT  course_name,class FROM 
`course_schedul`,`course`,`parent`,`stuent`, `course_has_course_schedul`
WHERE  `idparent`=`stuent_parent_idparent` AND idcourse=course_idcourse 
AND `idparent`=`course_schedul_stuent_parent_idparent`  AND  email='saber@gmail.com'";
$stmat=$conn->prepare($sql);
$stmat->execute();
 while($row =$stmat->fetch(PDO::FETCH_ASSOC))
{
    $arr[]=
         $row['course_name'];
         $arr1[]=
         $row['class'];


}
//print_r( $arr[1]);
 
  

 


 
?>