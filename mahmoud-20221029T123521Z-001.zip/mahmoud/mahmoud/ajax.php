<?php 
if(isset($_GET['stuent'])&& !empty($_GET['stuent']))
{
include('connected.php');
$id=$_GET['stuent'];
$query="SELECT * FROM `route` WHERE idroute='111'";
$stmat=$conn->prepare($query);
$stmat->execute();
$rowcount=$stmat->rowCount($query);
if($rowcount >0){
    while($row =$stmat->fetch(PDO::FETCH_ASSOC)){echo '<option value="'.$row['idroute'].'">'.$row['name'].'</option>';}
}
else{echo "Not Avalable";}
}
else
{
echo '<h1>error</h>';
}


?>