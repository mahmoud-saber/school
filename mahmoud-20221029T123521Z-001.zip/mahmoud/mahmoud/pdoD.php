<?php 
include 'connected.php' ;

$em = $_SESSION['email'];


$pdoquery="SELECT * FROM driver where email ='".$em."'" ; /*add where condition yasta */ 

$pdoquery_run=$conn->query($pdoquery) ;



?>