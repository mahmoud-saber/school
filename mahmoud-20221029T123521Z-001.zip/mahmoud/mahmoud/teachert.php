<?php include 'connected.php'?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <title>try</title>
  </head>
  <body>
      <center>
          <?php include 'codeteacher.php';?>
  <table border="1" cellspacing="0">

        <tr> 
         <th colspan="7"> Time Table </th>
		</tr>
		
         <tr>
         <th> Days </th>
         <th> course </th>
         <th> time  </th>
         <th> solt </th>
         <th> class</th>
  
        </tr>

         
        <tr>
         <td> 
           <?php 
         if($arr6[0]!="Saturday"){
          @print_r( $arr5[0]);
        }
          else{ @print_r( $arr6[0]);}
         ?> 
         </td>
    
         <td> <?php @print_r( $arr1[0])?> </td>
         <td>  <?php @print_r( $arr3[0]);?> </td></td>
         <td>  <?php @print_r( $arr2[0]);?> </td></td>
         <td> <?php @print_r( $arr4[0]);?> </td></td>
          </tr>
		
        <tr>
        <td> 
           <?php 
         if($arr6[0]!="Sunday"){
          @print_r( $arr5[1]);
        }
          else{ @print_r( $arr6[0]);}
         ?> 
         </td> 
        <td> <?php @print_r( $arr1[1])?> </td>
         <td>  <?php @print_r( $arr3[1]);?> </td></td>
         <td>  <?php @print_r( $arr2[1]);?> </td></td>
         <td> <?php @print_r( $arr4[1]);?> </td></td>
          </tr>
		
    <tr>
    <td> 
           <?php 
         if($arr6[0]!="Monday"){
          @print_r( $arr5[2]);
        }
          else{ @print_r( $arr6[0]);}
         ?> 
         </td>         
         <td> <?php @print_r( $arr1[2])?> </td>
         <td>  <?php @print_r( $arr3[2]);?> </td></td>
         <td>  <?php @print_r( $arr2[2]);?> </td></td>
         <td> <?php @print_r( $arr4[2]);?> </td></td>
          </tr>

          <tr>
          <td> 
           <?php 
         if($arr6[0]!="Tuesday"){
          @print_r( $arr5[3]);
        }
          else{ @print_r( $arr6[0]);}
         ?> 
         </td>          
         <td> <?php @print_r( $arr1[3])?> </td>
         <td>  <?php @print_r( $arr3[3]);?> </td></td>
         <td>  <?php @print_r( $arr2[3]);?> </td></td>
         <td> <?php @print_r( $arr4[3]);?> </td></td>
          </tr>

          <tr>
          <td> 
           <?php 
         if($arr6[0]!="Wednesday"){
          @print_r( $arr5[4]);
        }
          else{ @print_r( $arr6[0]);}
         ?> 
         </td>         
         <td> <?php @print_r( $arr1[4])?> </td>
         <td>  <?php @print_r( $arr3[4]);?> </td></td>
         <td>  <?php @print_r( $arr2[4]);?> </td></td>
         <td> <?php @print_r( $arr4[4]);?> </td></td>
          </tr>

          <tr>
          <td> 
            
           <?php @print_r( $arr6[0]);?>
         </td> 
         			<th colspan="6"> Day Off </th>
    </tr>
         
  </table>
</center>
  </body>