<?php 
include 'connected.php' ;
$em = $_SESSION['email'];
$pdoquery="  SELECT *
FROM `stuent` WHERE  `email_s`='$em'   " ;

$pdoquery_run=$conn->query($pdoquery) ;



?>