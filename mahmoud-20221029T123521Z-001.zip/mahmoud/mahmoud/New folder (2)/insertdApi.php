 <?php
 include 'connectdb.php';
header('content-type:application/json');

$filename=$_FILES['image']['name'];
$filesize=$_FILES['image']['size'];
$filetmp_name=$_FILES['image']['tmp_name'];
$filetype=$_FILES['image']['type'];
$imagAllowExtension=array("jpeg","png","jpg","gif");
$imagExtension=strtolower(end(explode('.',  $filename)));

$username=$_POST['username'];
$email=$_POST['email'];
$password= sha1( $_POST['password']);
 $age=$_POST['age'];
//$state_number=$_POST['state_number'];
$license=$_POST['license'];
$country=$_POST['country'];
$city=$_POST['city'];
$street=$_POST['street'];

$formErrors=array();

if(strlen($username)<4)
{
    $formErrors[]='Username Cant Be Less Than<strong>4 Characters</strong>';
}

if(strlen($username)>20)
{
    $formErrors[]='Username Cant Be More Than <strong>20 Characters</strong>';
}
if(empty($username))
{
    $formErrors[]='Username Cant Be  <strong> Empty</strong>';
}
if(empty($email))
{
    $formErrors[]='Email Cant Be  <strong> Empty</strong>';
}
/*if(empty($state_number))
{
    $formErrors[]='state_number Cant Be  <strong> Empty</strong>';
}
*/
if(empty($license))
{
    $formErrors[]='license Cant Be  <strong> Empty</strong>';
}

if(empty($password))
{
    $formErrors[]='Password Cant Be  <strong> Empty</strong>';
}
if(empty($age))
{
    $formErrors[]='age Cant Be  <strong> Empty</strong>';
}


if(empty($country))
{
    $formErrors[]='Country Cant Be  <strong> Empty</strong>';
}
if(empty($city))
{
    $formErrors[]='City Cant Be  <strong> Empty</strong>';
}
if(empty($street))
{
    $formErrors[]='Street Cant Be  <strong> Empty</strong>';
}


if(empty($filename))
{
    $formErrors[]='Image Is  <strong> Requert</strong>';
}

if(empty($filename) && ! in_array($imagExtension,$imagAllowExtension))
{
    $formErrors[]='Extension Is Not <strong> Allow</strong>';
}


/*if(empty($filesize < 104857600))
{
    $formErrors[]='Image Cant Be  <strong> 60M</strong>';
}
*/


foreach($formErrors as $error){ echo '<div class="alert alert-danger">'.$error.'</div>';}

if(empty($formErrors))
{
    $avatar=rand(0,100000000).'_'.$filename;
    move_uploaded_file($filetmp_name,"../../upload/images/".$avatar);
$stmt = $conn->prepare("INSERT INTO `driver` (username, email ,
password,image,age,license,country,city,street)
VALUES('$username','$email','$password', '$avatar','$age',
'$license','$country','$city','$street') ");
$stmt->bindParam(':username', $username,PDO::PARAM_STR );
 $stmt->bindParam(':email',$email ,PDO::PARAM_STR );
 $stmt->bindParam(':password' ,$password,PDO::PARAM_STR );
$stmt->bindParam(':image',$avatar ,PDO::PARAM_STR );
 //$stmt->bindParam(':state_number',$state_number, PDO::PARAM_STR) ;
 $stmt->bindParam(':license',$license,PDO::PARAM_STR  );
 $stmt->bindParam(':country',$country,PDO::PARAM_STR  );
 $stmt->bindParam(':city',$city,PDO::PARAM_STR  );
 $stmt->bindParam(':street',$street,PDO::PARAM_STR );
 $stmt->bindParam(':age',$age,PDO::PARAM_STR );
 $stmt->execute();
}
    if($stmt)
    {

        $data=array(

            "username"=>strval($username),
            "email"=>strval($email),
             "password"=>strval($password),
             "image"=>strval("/upload/images/".$avatar),
            //"state_number"=>strval($state_number),
            "license"=>strval($license),
            "country"=>strval($country),
            "city"=>strval($city),
            "street"=>strval($street),
            "age"=>strval($age)
        );



     }
    else
    {
        echo "NOT insert" ;
    }
  echo json_encode($data);
  ?>
