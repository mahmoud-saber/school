<?php

$host="localhost";
$user="id14069873_myschool2025";
$password="]wYMk-<bH5uMEJRQ";

$options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
    );

try
{
    $conn = new PDO("mysql:host=$host;dbname=id14069873_final", $user, $password);
    //echo "connection successful";

}
catch(PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();

}

?>
