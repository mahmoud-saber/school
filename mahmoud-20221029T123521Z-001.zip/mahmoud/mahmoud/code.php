<?php
include 'connected.php';
$sql=" SELECT  idcourse,course_name,class FROM 
`course_schedul`,`course`,`stuent`, `course_has_course_schedul`
WHERE  `idstuent`=`stuent_idstuent` AND `idcourse`=`course_idcourse` 
AND `idstuent`=`course_schedul_stuent_idstuent` AND email_s='mohsen@gmail.com'";
$stmat=$conn->prepare($sql);
$stmat->execute();
 while($row =$stmat->fetch(PDO::FETCH_ASSOC))
{
    $arr[]=
         $row['course_name'];
         $arr1[]=
         $row['class'];

}
//print_r( $arr[0]);
 
  

 


 
?>