<?php 
include 'connected.php' ;

$em = $_SESSION['email'];
$pdoquery="  SELECT *
FROM `parent`,`stuent` WHERE `idparent`=`parent_idparent`    
AND email='$em'   " ;

$pdoquery_run=$conn->query($pdoquery) ;



?>