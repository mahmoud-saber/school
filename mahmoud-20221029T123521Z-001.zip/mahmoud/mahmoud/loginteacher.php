<?php 
include 'connected.php';
session_start();

?>
<?php 
  if(isset($_POST['login'])){
$sql = "select email,password from teacher";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll();

foreach ($result as $row) {
if($row[0] == $_POST['email'] && $row[1] == sha1( $_POST['password'])){

  $_SESSION['email'] = $_POST['email'];

      header('Location:profileT.php');//profileT.php
    } 

}
//echo "<script>alert('invaled');</script>";
echo "<h1>error</h1>";

}
else{
  echo "error";
}
?> 