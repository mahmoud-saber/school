<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="x-ua-compatible" content="IE=9" /><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KIDS - Kindergarten and Child Care Html Templates</title>
    <meta name="description" content="KIDS is a clean, modern, and fully responsive Html Template. Take your Startup business website to the next level. It is designed for kindergarten, childcare, homeschooling, school, learning, playground businesses or any type of person or business who wants to showcase their work, services and professional way.">
    <meta name="keywords" content="business, care, childcare, children, clean, corporate, happykids, homeschool, kids, kindergarten, playground, responsive, school, learning">
    <meta name="author" content="rometheme.net"> 
	
	<!-- ==============================================
	Favicons
	=============================================== -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
	
	<!-- ==============================================
	CSS VENDOR
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/vendor/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.theme.default.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/magnific-popup.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/animate.min.css">
	
	<!-- ==============================================
	Custom Stylesheet
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
    <script src="js/vendor/modernizr.min.js"></script>

</head>

<body>

	<!-- LOAD PAGE -->
	<div class="animationload">
		<div class="loader"></div>
	</div>
	
	<!-- BACK TO TOP SECTION -->
	<a href="#0" class="cd-top cd-is-visible cd-fade-out">Top</a>

	<!-- HEADER -->
    <div class="header header-1">

    	<!-- TOPBAR -->
    	<div class="topbar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-sm-8 col-md-6">
						<div class="info">
							<div class="info-item">
								<i class="fa fa-phone"></i> 01066258970
							</div>
							<div class="info-item">
								<i class="fa fa-envelope-o"></i> <a href="mailto:hagarhay@gmail.com" title="">hagarhay@gmail.com</a>
							</div>
						</div>
					</div>
					<div class="col-sm-4 col-md-6">
						<div class="sosmed-icon pull-right d-inline-flex">
							<a href="#" class="fb"><i class="fa fa-facebook"></i></a> 
							 
							<a href="#" class="ig"><i class="fa fa-instagram"></i></a> 
							
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- NAVBAR SECTION -->
		<div class="navbar-main">
			<div class="container">
			    <nav id="navbar-example" class="navbar navbar-expand-lg">
			        <a class="navbar-brand" href="home.html">
						<img src="images/school.jpg" alt="" width=200px height=90px>
					</a>
			        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
			            <span class="navbar-toggler-icon"></span>
			        </button>
			        <div class="collapse navbar-collapse" id="navbarNavDropdown">
			            <ul class="navbar-nav ml-auto">
			            	<li class="nav-item active">
			                    <a class="nav-link" href="home.html">HOME</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="registration.php">REGISTRATION</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="parents.html">PARENTS</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="teachers.html">TEACHERS</a>
							</li>
							<li class="nav-item">
			                    <a class="nav-link" href="students.html">STUDENTS</a>
							</li>
							<li class="nav-item">
			                    <a class="nav-link" href="drivers.html">DRIVERS</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="contact.html">CONTACT US</a>
			                </li>
			            </ul>
			        </div>
			    </nav> <!-- -->

			</div>
		</div>

    </div>

	<!-- BANNER -->
    <div id="oc-fullslider" class="banner">
    	<div class="owl-carousel owl-theme full-screen">
	    	<div class="item">
	        	<img src="images/Students.jpeg" alt="Slider">
	        	<div class="overlay-bg"></div>
	        	<div class="container d-flex align-items-center">
	            	<div class="wrap-caption">
	            		<h5 class="caption-supheading">Welcome to School</h5>
		                <h1 class="caption-heading">Best students at any school</h1>
		                <!--<a href="#" class="btn btn-secondary">LEARN MORE</a>-->
		            </div>  
	            </div>
	    	</div>
	    	<div class="item">
	            <img src="images/teachers.jpg" alt="Slider">
	            <div class="overlay-bg"></div>
	            <div class="container d-flex align-items-center">
	            	<div class="wrap-caption">
		                <h5 class="caption-supheading">Welcome to school</h5>
		                <h1 class="caption-heading">Best teachers at any school</h1>
		                <a href="#" class="btn btn-secondary">LEARN MORE</a>
		            </div>  
	            </div>
	        </div>  
	    	<div class="item">
	            <img src="images/parents.jpg" alt="Slider"> 
	            <div class="overlay-bg"></div>
	            <div class="container d-flex align-items-center">
	            	<div class="wrap-caption">
		                <h5 class="caption-supheading">Welcome to school</h5>
		                <h1 class="caption-heading">Best parents for their child</h1>
		                <a href="#" class="btn btn-secondary">LEARN MORE</a>
		            </div>  
	            </div>
	        </div>  
    	</div>
	    <div class="custom-nav owl-nav"></div>
    </div>	

	<!-- WELCOME TO KIDS -->
	<div class="section">
		<div class="content-wrap">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12 col-lg-6">
						<img src="images/logo page.png" alt="" class="img-fluid img-border">
					</div>
					<div class="col-sm-12 col-md-12 col-lg-6">
						<h2 class="section-heading">
							Welcome to SCHOOL
						</h2>
						<p></p>
						<p></p>
						<div class="spacer-10"></div>
						<a href="#" class="btn btn-secondary">DISCOVER MORE</a>
						<div class="spacer-30"></div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- FUNFACT -->
	<div class="section bgi-overlay bgi-cover-center" data-background="images/school1.jpg">
		<div class="content-wrap">
			<div class="container">
				<div class="row">
					<!-- Item 1 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-primary">
							<div class="box-fun"><h2>852</h2></div>
							<div class="title">Students</div>	
						</div>
					</div>
					<!-- Item 2 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-secondary">
							<div class="box-fun"><h2>125</h2></div>
							<div class="title">Teachers</div>	
						</div>
					</div>
					<!-- Item 3 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-tertiary">
							<div class="box-fun"><h2>32</h2></div>
							<div class="title">Class Rooms</div>	
						</div>
					</div>
					<!-- Item 4 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-quaternary">
							<div class="box-fun"><h2>15</h2></div>
							<div class="title">Bus Schools</div>	
						</div>
					</div>
				</div>
			</div>
		</div> 
	</div>

	<!-- OUR GALLERY -->
	<div class="">
		<div class="content-wrap">
			<div class="container">

				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="supheading text-center">Our Gallery</p>
						<h2 class="section-heading text-center mb-5">
							Moment from SCHOOL
						</h2>
					</div>
				</div>
				
				<div class="row popup-gallery gutter-5">
					<!-- Item 1 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="0-5761_teacher-png-teacher-clipart-png.png" title="Gallery #1">
								<img src="0-5761_teacher-png-teacher-clipart-png.png" alt="" class="img-fluid">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 1 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="40c3ea0ef59d4470e30d419a0cc9fcd1.jpg" title="Gallery #2" width="600px" height="400px">
								<img src="40c3ea0ef59d4470e30d419a0cc9fcd1.jpg" alt="" class="img-fluid" width="600px" height="400px">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 1 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="86486778-vector-illustration-background-follow-up.jpg" title="Gallery #3">
								<img src="86486778-vector-illustration-background-follow-up.jpg" alt="" class="img-fluid">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 2 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="images/dummy-img-600x400.jpg" title="Gallery #4">
								<img src="images/dummy-img-600x400.jpg" alt="" class="img-fluid">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 3 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="images/dummy-img-600x400.jpg" title="Gallery #5">
								<img src="images/dummy-img-600x400.jpg" alt="" class="img-fluid">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					<!-- Item 4 -->
					<div class="col-xs-12 col-md-6 col-lg-4">
						<div class="box-gallery">
							<a href="images/dummy-img-600x400.jpg" title="Gallery #6">
								<img src="images/dummy-img-600x400.jpg" alt="" class="img-fluid">
								<div class="project-info">
									<div class="project-icon">
										<span class="fa fa-search"></span>
									</div>
								</div>
							</a>
						</div>
					</div>
					
				</div>
				
			</div>
		</div>
	</div>

	
	<!-- WHY CHOOSE US -->
	<div class="section bgi-repeat" data-background="images/dummy-img-1920x900-3.jpg">
		<div class="content-wrap pb-0">
			<div class="container">
				<div class="row align-items-end">
					<div class="col-sm-12 col-md-12 col-lg-7">
						<p class="supheading">Why Choose Us</p>
						<h2 class="section-heading">
							Best SCHOOL
						</h2>
						<p class="text-white"> </p>
						<p class="p-check text-white"></p>
						<p class="p-check text-white"></p>
						<p class="p-check text-white"></p>
						<!--<div class="spacer-90"></div>-->
					</div>
					<div class="col-sm-12 col-md-12 col-lg-5">
						<img src="images/dummy-img-600x700.jpg" alt="" class="img-fluid">
					</div>
				</div>
				
			</div>
		</div>
	</div>


	<!-- OUR EVENTS -->
	<div class="section bgi-cover-center" data-background="images/dummy-img-1920x900-2.jpg">
		<div class="content-wrap">
			<div class="container">

				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="supheading text-center">Our Events</p>
						<h2 class="section-heading text-center mb-5">
							Don't miss our event
						</h2>
					</div>
				</div>

				<div class="row mt-4">
					
					<!-- Item 1 -->
					<div class="col-sm-12 col-md-12 col-lg-4 mb-5">
						<div class="rs-news-1">
							<div class="media-box">
								<img src="images/dummy-img-600x400.jpg" alt="" class="img-fluid">
							</div>
							<div class="body-box">
								<div class="title">English Day on Carfree day</div>
								<div class="meta-date">March 19, 2016 / 08:00 am - 10:00 am</div>
								<p>We provide high quality design at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores...</p>
								<div class="text-center">
									<a href="page-events-single.html" class="btn btn-primary">JOIN NOW</a>
								</div>
							</div>
						</div>
					</div>

					<!-- Item 2 -->
					<div class="col-sm-12 col-md-12 col-lg-4 mb-5">
						<div class="rs-news-1">
							<div class="media-box">
								<img src="images/dummy-img-600x400.jpg" alt="" class="img-fluid">
							</div>
							<div class="body-box">
								<div class="title">Play & Study with Mrs. Smith</div>
								<div class="meta-date">March 19, 2016 / 08:00 am - 10:00 am</div>
								<p>We provide high quality design at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores...</p>
								<div class="text-center">
									<a href="page-events-single.html" class="btn btn-primary">JOIN NOW</a>
								</div>
							</div>
						</div>
					</div>

					<!-- Item 3 -->
					<div class="col-sm-12 col-md-12 col-lg-4 mb-5">
						<div class="rs-news-1">
							<div class="media-box">
								<img src="images/dummy-img-600x400.jpg" alt="" class="img-fluid">
							</div>
							<div class="body-box">
								<div class="title">Drawing at City Park</div>
								<div class="meta-date">March 19, 2016 / 08:00 am - 10:00 am</div>
								<p>We provide high quality design at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores...</p>
								<div class="text-center">
									<a href="page-events-single.html" class="btn btn-primary">JOIN NOW</a>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>
		</div>
	</div>

	<!-- OUR TESTIMONIALS -->
	<div class="section">
		<div class="content-wrap">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="supheading text-center">Our Testimonials</p>
						<h2 class="section-heading text-center mb-5">
							What parents say
						</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12 col-md-10 offset-md-1">
						<div class="text-center text-secondary mb-3"><i class="fa fa-quote-right fa-3x"></i></div>
						<div id="testimonial" class="owl-carousel owl-theme">
							<div class="item">
								<div class="rs-box-testimony">
									<div class="quote-box">
										<blockquote>
										 Teritatis et quasi architecto. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore mque laudantium, totam rem aperiam
										</blockquote>
										<div class="media">
											<img src="images/dummy-img-400x400.jpg" alt="" class="rounded-circle">
										</div>
										<p class="quote-name">
											Johnathan Doel <span>Businessman</span>
										</p>                        
									</div>
								</div>
							</div>
							<div class="item">
								<div class="rs-box-testimony">
									<div class="quote-box">
										<blockquote>
										 Teritatis et quasi architecto. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore mque laudantium, totam rem aperiam
										</blockquote>
										<div class="media">
											<img src="images/dummy-img-400x400.jpg" alt="" class="rounded-circle">
										</div>
										<p class="quote-name">
											Johnathan Doel <span>CEO Buka Kreasi</span>
										</p>                        
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- CTA -->
	<div class="section bg-tertiary">
		<div class="content-wrap py-5">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-sm-12 col-md-12">
						<div class="cta-1">
			              	<div class="body-text mb-3">
			                	<h3 class="my-1 text-secondary">Let's join the best kindergarten now!</h3>
			                	<p class="uk18 mb-0 text-white">We provide high standar clean website for your business solutions</p>
			              	</div>
			              	<div class="body-action">
			                	<a href="contact.html" class="btn btn-primary mt-3">CONTACT US</a>
			              	</div>
			            </div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- FOOTER SECTION -->
	<div class="footer" data-background="images/dummy-img-1920x900-3.jpg">
		<div class="content-wrap">
			<div class="container">
				
				<div class="row">
					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<img src="images/logo.png" alt="logo bottom" class="logo-bottom">
							<div class="spacer-30"></div>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy.</p>
							<a href="#"><i class="fa fa-angle-right"></i> Read More</a>
						</div>
					</div>					

					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title">
								Contact Info
							</div>
							<ul class="list-info">
								<li>
									<div class="info-icon">
										<span class="fa fa-map-marker"></span>
									</div>
									<div class="info-text">99 S.t Jomblo Park Pekanbaru 28292. Indonesia</div> </li>
								<li>
									<div class="info-icon">
										<span class="fa fa-phone"></span>
									</div>
									<div class="info-text">(0761) 654-123987</div>
								</li>
								<li>
									<div class="info-icon">
										<span class="fa fa-envelope"></span>
									</div>
									<div class="info-text">info@yoursite.com</div>
								</li>
								<li>
									<div class="info-icon">
										<span class="fa fa-clock-o"></span>
									</div>
									<div class="info-text">Mon - Sat 09:00 - 17:00</div>
								</li>
							</ul>

						</div>
					</div>

					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title">
								Useful Links
							</div>
							
							<ul class="list">
								<li><a href="about.html" title="About us">About us</a></li>
								<li><a href="teachers.html" title="Our Teacher">Our Teacher</a></li>
								<li><a href="classes.html" title="Our Classes">Our Classes</a></li>
								<li><a href="page-events.html" title="Our Events">Our Events</a></li>
								<li><a href="contact.html" title="Contact Us">Contact Us</a></li>
							</ul>
								
						</div>
					</div>
					
					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title">
								Get in Touch
							</div>
							<p>Lit sed The Best in dolor sit amet consectetur adipisicing elit sedconsectetur adipisicing</p>
							<div class="sosmed-icon d-inline-flex">
								<a href="#" class="fb"><i class="fa fa-facebook"></i></a> 
								<a href="#" class="tw"><i class="fa fa-twitter"></i></a> 
								<a href="#" class="ig"><i class="fa fa-instagram"></i></a> 
								<a href="#" class="in"><i class="fa fa-linkedin"></i></a> 
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="fcopy">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="ftex">Copyright 2019 &copy; <span class="color-primary">Kids HTML Template</span>. Designed by <span class="color-primary">Rometheme.</span></p> 
					</div>
				</div>
			</div>
		</div>
		
	</div>
	
	<!-- JS VENDOR -->
	<script src="js/vendor/jquery.min.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/vendor/owl.carousel.js"></script>
	<script src="js/vendor/jquery.magnific-popup.min.js"></script>

	<!-- SENDMAIL -->
	<script src="js/vendor/validator.min.js"></script>
	<script src="js/vendor/form-scripts.js"></script>

	<script src="js/script.js"></script>

</body>
</html>