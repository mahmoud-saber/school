<?php
 include 'connected.php'?>
<?php
if(isset($_POST['Submit'])){
    $username=$_POST['username'];
    $email=$_POST['email'];
    $password= sha1( $_POST['password']);
    $gender=$_POST['gender'];
    $phone=$_POST['phone'];

     
 
    
    $stmt = $conn->prepare("INSERT INTO `parent` (`usernam`,`email` ,`password`,`gender`)  
    VALUES('$username','$email','$password','$gender');
     INSERT INTO `parentphone`(`phone`,`parent_idparent`) VALUE('$phone',
     (SELECT idparent FROM `parent` WHERE email='$email')) ")  ;
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email',$email);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':gender',$gender);
    $stmt->bindParam(':phone',$phone);

    $stmt ->execute();
    header('Location: parents.php');


}
else{
    echo "invaled";
}



?>