<?php
 $db=mysqli_connect("localhost","root","");
 $dbs=mysqli_select_db($db,"final");
?>