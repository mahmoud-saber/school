<?php include 'connected.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="x-ua-compatible" content="IE=9" /><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KIDS - Kindergarten and Child Care Html Templates</title>
    <meta name="description" content="KIDS is a clean, modern, and fully responsive Html Template. Take your Startup business website to the next level. It is designed for kindergarten, childcare, homeschooling, school, learning, playground businesses or any type of person or business who wants to showcase their work, services and professional way.">
    <meta name="keywords" content="business, care, childcare, children, clean, corporate, happykids, homeschool, kids, kindergarten, playground, responsive, school, learning">
    <meta name="author" content="rometheme.net"> 
	
	<!-- ==============================================
	Favicons
	=============================================== -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
	
	<!-- ==============================================
	CSS VENDOR
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/vendor/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.theme.default.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/magnific-popup.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/animate.min.css">
	
	<!-- ==============================================
	Custom Stylesheet
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
    <script src="js/vendor/modernizr.min.js"></script>

</head>

<body>

	<!-- LOAD PAGE -->
	<div class="animationload">
		<div class="loader"></div>
	</div>
	
	<!-- BACK TO TOP SECTION -->
	<a href="#0" class="cd-top cd-is-visible cd-fade-out">Top</a>

	<!-- HEADER -->
    <div class="header header-1">

    	<!-- TOPBAR -->
    	<div class="topbar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-sm-8 col-md-6">
						<div class="info">
							<div class="info-item">
								<i class="fa fa-phone"></i> 01066258970
							</div>
							<div class="info-item">
								<i class="fa fa-envelope-o"></i> <a href="mailto:hagarhay@gmail.com" title="">hagarhay@gmail.com</a>
							</div>
						</div>
					</div>
					<div class="col-sm-4 col-md-6">
						<div class="sosmed-icon pull-right d-inline-flex">
							<a href="#" class="fb"><i class="fa fa-facebook"></i></a> 
							
							<a href="#" class="ig"><i class="fa fa-instagram"></i></a> 
							
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- NAVBAR SECTION -->
		<div class="navbar-main">
			<div class="container">
			    <nav id="navbar-example" class="navbar navbar-expand-lg">
			        <a class="navbar-brand" href="index.html">
						<img src="images/school.jpg" alt="" width=200px height=90px>
					</a>
			        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
			            <span class="navbar-toggler-icon"></span>
			        </button>
			        <div class="collapse navbar-collapse" id="navbarNavDropdown">
			            <ul class="navbar-nav ml-auto">
			            	<li class="nav-item">
			                    <a class="nav-link" href="home.php">HOME</a>
			                </li>
			            	<li class="nav-item active">
			                    <a class="nav-link" href="registration.php">REGISTRATION</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="parents.php">PARENTS</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="teachers.php">TEACHERS</a>
							</li>
							<li class="nav-item">
			                    <a class="nav-link" href="students.php">STUDENTS</a>
							</li>
							<li class="nav-item">
			                    <a class="nav-link" href="drivers.php">DRIVERS</a>
			                </li>
			            	<li class="nav-item">
			                    <a class="nav-link" href="contact.html">CONTACT US</a>
			                </li>
			            </ul>
			        </div>
			    </nav> <!-- -->

			</div>
		</div>

    </div>

	<!-- BANNER -->
	<div class="section banner-page" data-background="images/registration.png">
		<div class="content-wrap pos-relative">
			<div class="d-flex justify-content-center bd-highlight mb-3">
				<div class="title-page">REGISTRATION</div>
			</div>
		</div>
	</div>

    <!-- SHORTCUT -->
	<div class="section services">
		<div class="content-wrap pb-0">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<div class="row col-0 no-gutters">
							<div class="col-sm-12 col-md-6 col-lg-6">
								<!-- BOX 1 -->
								<a href="Regstudent.php"><div class="rs-feature-box-1 bg-primary">
									<i class="fa fa-users"></i>
									<div class="body">
										<h1>STUDENTS</h1>
										
										<div class="spacer-10"></div>
										<a href="Regstudent.php" class="btn">SIGN UP</a>
									</div>
					            </div></a>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6">
								<!-- BOX 2 -->
								<a href="Regparent.php"><div class="rs-feature-box-1 bg-secondary">
									<i class="fa fa-home"></i>
									<div class="body">
										<h1>PARENTS</h1>
										
										<div class="spacer-10"></div>
										<a href="Regparent.php" class="btn">SIGN UP</a>
									</div>
					            </div></a>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6">
								<!-- BOX 3 -->
								<a href="Regteacher.php"><div class="rs-feature-box-1 bg-tertiary">
									<i class="fa fa-user"></i>
									<div class="body">
										<h1>TEACHERS</h1>
										<div class="spacer-10"></div>
										<a href="Regteacher.php"class="btn">SIGN UP</a>
									</div>
					            </div></a>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6">
								<!-- BOX 4 -->
								<a href="Regdriver.php"><div class="rs-feature-box-1 bg-fifth">
									<i class="fa fa-car"></i>
									<div class="body">
										<h1>DRIVERS</h1>
										
										<div class="spacer-10"></div>
										<a href="Regdriver.php" class="btn">SIGN UP</a>
									</div>
					            </div></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>	

	<!-- WHY CHOOSE US -->
	<div class="section">
		<div class="content-wrap pb-0">
			<div class="container">
				<div class="row align-items-end">
					<div class="col-sm-12 col-md-12 col-lg-7">
						<p class="supheading">Why Choose Us</p>
						<h2 class="section-heading mb-5">
							Best Kindergarten
						</h2>
						<p class="">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.  Praesent interdum est gravida vehicula est node maecenas loareet morbi a dosis luctus novum est praesent.  Praesent interdum est gravida vehicula est node maecenas loareet morbi a dosis luctus novum est praesent.</p>
						<p class="p-check ">100% education, for your kids, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
						<p class="p-check ">More programs activities, sed diam nonummy nibh euismod. Lorem ipsum dolor sit amet.</p>
						<p class="p-check ">More benefit nonummy nibh euismod. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
						<div class="spacer-90"></div>
					</div>
					<div class="col-sm-12 col-md-12 col-lg-5">
						<img src="images/dummy-img-600x700.jpg" alt="" class="img-fluid">
					</div>
				</div>
				
			</div>
		</div>
	</div>

	<!-- WELCOME TO KIDS -->
	<div class="section bgi-overlay bgi-cover-center" data-background="images/dummy-img-1920x900-2.jpg">
		<div class="content-wrap">
			<div class="container">
				<div class="row">
					<!-- Item 1 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-primary">
							<div class="box-fun"><h2>852</h2></div>
							<div class="title">Students</div>	
						</div>
					</div>
					<!-- Item 2 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-secondary">
							<div class="box-fun"><h2>125</h2></div>
							<div class="title">Teachers</div>	
						</div>
					</div>
					<!-- Item 3 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-tertiary">
							<div class="box-fun"><h2>32</h2></div>
							<div class="title">Class Rooms</div>	
						</div>
					</div>
					<!-- Item 4 -->
					<div class="col-sm-6 col-md-3">
						<div class="rs-funfact bg-quaternary">
							<div class="box-fun"><h2>15</h2></div>
							<div class="title">Bus Schools</div>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- OUR TESTIMONIALS -->
	<div class="section">
		<div class="content-wrap">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="supheading text-center">Our Testimonials</p>
						<h2 class="section-heading text-center mb-5">
							What parents say
						</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12 col-md-10 offset-md-1">
						<div class="text-center text-secondary mb-3"><i class="fa fa-quote-right fa-3x"></i></div>
						<div id="testimonial" class="owl-carousel owl-theme">
							<div class="item">
								<div class="rs-box-testimony">
									<div class="quote-box">
										<blockquote>
										 Teritatis et quasi architecto. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore mque laudantium, totam rem aperiam
										</blockquote>
										<div class="media">
											<img src="images/dummy-img-400x400.jpg" alt="" class="rounded-circle">
										</div>
										<p class="quote-name">
											Johnathan Doel <span>Businessman</span>
										</p>                        
									</div>
								</div>
							</div>
							<div class="item">
								<div class="rs-box-testimony">
									<div class="quote-box">
										<blockquote>
										 Teritatis et quasi architecto. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore mque laudantium, totam rem aperiam
										</blockquote>
										<div class="media">
											<img src="images/dummy-img-400x400.jpg" alt="" class="rounded-circle">
										</div>
										<p class="quote-name">
											Johnathan Doel <span>CEO Buka Kreasi</span>
										</p>                        
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- CTA -->
	<div class="section bg-tertiary">
		<div class="content-wrap py-5">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-sm-12 col-md-12">
						<div class="cta-1">
			              	<div class="body-text mb-3">
			                	<h3 class="my-1 text-secondary">Let's join the best kindergarten now!</h3>
			                	<p class="uk18 mb-0 text-white">We provide high standar clean website for your business solutions</p>
			              	</div>
			              	<div class="body-action">
			                	<a href="contact.html" class="btn btn-primary mt-3">CONTACT US</a>
			              	</div>
			            </div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- FOOTER SECTION -->
	<div class="footer" data-background="images/dummy-img-1920x900-3.jpg">
		<div class="content-wrap">
			<div class="container">
				
				<div class="row">
					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<img src="images/logo.png" alt="logo bottom" class="logo-bottom">
							<div class="spacer-30"></div>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy.</p>
							<a href="#"><i class="fa fa-angle-right"></i> Read More</a>
						</div>
					</div>					

					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title">
								Contact Info
							</div>
							<ul class="list-info">
								<li>
									<div class="info-icon">
										<span class="fa fa-map-marker"></span>
									</div>
									<div class="info-text">99 S.t Jomblo Park Pekanbaru 28292. Indonesia</div> </li>
								<li>
									<div class="info-icon">
										<span class="fa fa-phone"></span>
									</div>
									<div class="info-text">(0761) 654-123987</div>
								</li>
								<li>
									<div class="info-icon">
										<span class="fa fa-envelope"></span>
									</div>
									<div class="info-text">info@yoursite.com</div>
								</li>
								<li>
									<div class="info-icon">
										<span class="fa fa-clock-o"></span>
									</div>
									<div class="info-text">Mon - Sat 09:00 - 17:00</div>
								</li>
							</ul>

						</div>
					</div>

					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title">
								Useful Links
							</div>
							
							<ul class="list">
								<li><a href="about.html" title="About us">About us</a></li>
								<li><a href="teachers.html" title="Our Teacher">Our Teacher</a></li>
								<li><a href="classes.html" title="Our Classes">Our Classes</a></li>
								<li><a href="page-events.html" title="Our Events">Our Events</a></li>
								<li><a href="contact.html" title="Contact Us">Contact Us</a></li>
							</ul>
								
						</div>
					</div>
					
					<div class="col-sm-12 col-md-6 col-lg-3">
						<div class="footer-item">
							<div class="footer-title">
								Get in Touch
							</div>
							<p>Lit sed The Best in dolor sit amet consectetur adipisicing elit sedconsectetur adipisicing</p>
							<div class="sosmed-icon d-inline-flex">
								<a href="#" class="fb"><i class="fa fa-facebook"></i></a> 
								<a href="#" class="tw"><i class="fa fa-twitter"></i></a> 
								<a href="#" class="ig"><i class="fa fa-instagram"></i></a> 
								<a href="#" class="in"><i class="fa fa-linkedin"></i></a> 
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="fcopy">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="ftex">Copyright 2019 &copy; <span class="color-primary">Kids HTML Template</span>. Designed by <span class="color-primary">Rometheme.</span></p> 
					</div>
				</div>
			</div>
		</div>
		
	</div>
	
	<!-- JS VENDOR -->
	<script src="js/vendor/jquery.min.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/vendor/owl.carousel.js"></script>
	<script src="js/vendor/jquery.magnific-popup.min.js"></script>
	<script src="js/vendor/isotope.pkgd.min.js"></script>
	<script src="js/vendor/imagesloaded.pkgd.min.js"></script>

	<!-- SENDMAIL -->
	<script src="js/vendor/validator.min.js"></script>
	<script src="js/vendor/form-scripts.js"></script>

	<script src="js/script.js"></script>

</body>
</html>