<?php
include 'connected.php';
$student = $_SESSION['email'];

/*$sql=" SELECT  idcourse,course_name,class,section FROM 
`course_schedul`,`course`,`stuent`, `course_has_course_schedul`
WHERE  `idstuent`=`stuent_idstuent` AND `idcourse`=`course_idcourse` 
AND `idstuent`=`course_schedul_stuent_idstuent` AND class='A1'";*/
$sql="select course_name,class from stuent,course,course_has_course_schedul where  
idcourse=course_idcourse and idstuent=course_schedul_stuent_idstuent	
and email_s='$student'
";
$stmat=$conn->prepare($sql);
$stmat->execute();
 while($row =$stmat->fetch(PDO::FETCH_ASSOC))
{
    $arr[]=
         $row['course_name'];
         $arr1[]=
         $row['class'];
         
}
/*print_r( $arr)."<br>";
echo"<br>";
print_r( $arr1)."<br>";
echo "<br>";
//print_r( $arr2)."<br>";

 */
  

 


 
?>