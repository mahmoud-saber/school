<?php

$host="localhost";
$user="root";
$password="";

$options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
    );
 
try
{
    $conn = new PDO("mysql:host=$host;dbname=finall", $user, $password);
    //echo "connection successful";

}
catch(PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();

}

?>
