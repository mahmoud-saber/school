<?php 
include 'connected.php' ;
$pdoquery="SELECT * FROM teacher where email='emad23@gmail.com' " ; /*add where condation yasta */ 
$pdoquery_run=$conn->query($pdoquery) ;

if($pdoquery_run){
echo '<table width ="200%" border="5" cellpadding="5" cellspacing="5" 
	<tr style="color:blue">
	<td >Name</td>
	<td>Gender</td>
	<td>E_mail</td>
	<td>BirthDay</td>
	<td>Career</td>
	</tr>
	
 ';
	while($row =$pdoquery_run->fetch(PDO::FETCH_OBJ))
	{
	
		echo '<tr >
		<td>'.$row->username.'</td>
		<td>'.$row->gender.'</td>
		<td>'.$row->email.'</td>
		<td>'.$row->age.'</td>
		<td>'.$row->career.'</td>
			</tr>
		' ;

	}
		echo '</table>';	
}

	else {
	echo '<script> alert("No registeration ") </script>' ;

	}


?>