<?php include 'connected.php';?>
 <?php
if(isset($_POST['Submit']))
{
    $date=$_POST['date'];
    $activity= $_POST['activity'];
    $marks=$_POST['marks'];
    $attendant=$_POST['attendant'];
    $mode=$_POST['mode'];
   // @$mode=implode(',',$ckeck_mode);
    $home_worke=$_POST['home_worke'];
    $coursename=$_POST['course_name'];
    $route_name=$_POST['name'];
    $eparent=$_POST['email'];
    $emails=$_POST['email_s'];
    
 
    $sql=" INSERT INTO `follow_up`( `date`, `activity`, `marks`, `attendant`,`mode`,`home_worke`,
       `course_idcourse`,
       `stuent_idstuent`, `stuent_parent_idparent`, `stuent_route_idroute`) VALUES ('$date',
     '$activity', '$marks','$attendant','$mode' ,'$home_worke' ,
     (SELECT idcourse FROM `course` WHERE course_name='$coursename' ),
      (SELECT idstuent FROM `stuent` WHERE email_s='$emails'),
      (SELECT idparent FROM `parent` WHERE email='$eparent'),
      (SELECT idroute FROM `route` WHERE name='$route_name'))";
       $result=$conn->prepare($sql);
       $result ->execute();
       mail($eparent,'follow_up',$coursename,$date);
       header('Location:page-follow.php');
        exit();
 
    }
     
    
 
?>